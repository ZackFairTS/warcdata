#!/usr/bin/env python3
"""
HTTP API for mem0 memory operations with S3 Vectors backend.
Supports per-user collection isolation: each user_id maps to a separate S3 Vectors index.

Run: uvicorn service:app --host 0.0.0.0 --port 8765
"""

import os
import logging
from typing import Optional, List, Dict, Any
from contextlib import asynccontextmanager
from threading import Lock

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from pydantic_settings import BaseSettings

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# ─── Settings ─────────────────────────────────────────────────────────
class Settings(BaseSettings):
    aws_region: str = "ap-northeast-1"
    vector_bucket_name: str = "openclaw-memory-vectors"
    base_collection_name: str = "mem0"           # prefix for per-user indexes
    legacy_collection_name: str = "mem0-memory"   # old shared index (read-only fallback)
    embedding_dims: int = 1024
    distance_metric: str = "cosine"
    llm_model: str = "jp.anthropic.claude-haiku-4-5-20251001-v1:0"
    embedder_model: str = "amazon.titan-embed-text-v2:0"

    class Config:
        env_prefix = "MEM0_"


settings = Settings()


# ─── Per-user Memory Instance Pool ───────────────────────────────────
_instances: Dict[str, Any] = {}   # collection_name -> Memory instance
_lock = Lock()


def _collection_for_user(user_id: str) -> str:
    """Map user_id to a collection (index) name."""
    # Sanitize: S3 Vectors index names allow [a-zA-Z0-9_-]
    safe = user_id.replace(" ", "-").replace("/", "-")
    return f"{settings.base_collection_name}-{safe}"


def _make_config(collection_name: str) -> Dict[str, Any]:
    os.environ["AWS_REGION"] = settings.aws_region
    return {
        "vector_store": {
            "provider": "s3_vectors",
            "config": {
                "vector_bucket_name": settings.vector_bucket_name,
                "collection_name": collection_name,
                "embedding_model_dims": settings.embedding_dims,
                "distance_metric": settings.distance_metric,
                "region_name": settings.aws_region,
            },
        },
        "llm": {
            "provider": "aws_bedrock",
            "config": {
                "model": settings.llm_model,
                "temperature": 0.1,
                "max_tokens": 2000,
            },
        },
        "embedder": {
            "provider": "aws_bedrock",
            "config": {
                "model": settings.embedder_model,
                "embedding_dims": settings.embedding_dims,
            },
        },
    }


def get_memory(user_id: str = "default"):
    """Return (or lazily create) a mem0 Memory instance for the given user_id."""
    collection = _collection_for_user(user_id)
    if collection in _instances:
        return _instances[collection], collection

    with _lock:
        # Double-check after acquiring lock
        if collection in _instances:
            return _instances[collection], collection

        from mem0 import Memory

        logger.info(f"Creating Memory instance: user_id={user_id} → index={collection}")
        config = _make_config(collection)
        instance = Memory.from_config(config)
        _instances[collection] = instance
        return instance, collection


# ─── FastAPI App ──────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Starting mem0 service (per-user isolation mode)...")
    # Pre-warm the "default" instance so /health is fast
    try:
        get_memory("default")
        logger.info("Default Memory instance ready")
    except Exception as e:
        logger.error(f"Failed to init default instance: {e}")
    yield
    logger.info("Shutting down mem0 service...")


app = FastAPI(
    title="Mem0 Service (per-user isolation)",
    description="HTTP API for mem0 with per-user S3 Vectors index isolation",
    version="2.0.0",
    lifespan=lifespan,
)


# ─── Request / Response models ────────────────────────────────────────
class AddRequest(BaseModel):
    messages: List[Dict[str, str]]
    user_id: str = "default"
    metadata: Optional[Dict[str, Any]] = None


class SearchRequest(BaseModel):
    query: str
    user_id: str = "default"
    limit: int = 5


class GetAllRequest(BaseModel):
    user_id: str = "default"
    limit: Optional[int] = None


class DeleteRequest(BaseModel):
    memory_id: str
    user_id: str = "default"


class UpdateRequest(BaseModel):
    memory_id: str
    data: str
    user_id: str = "default"


class MemoryResponse(BaseModel):
    id: str
    memory: str
    metadata: Optional[Dict[str, Any]] = None
    score: Optional[float] = None


class SearchResponse(BaseModel):
    results: List[MemoryResponse]


class StatusResponse(BaseModel):
    status: str
    bucket: str
    base_collection: str
    legacy_collection: str
    region: str
    llm_model: str
    embedder_model: str
    active_collections: List[str]


# ─── Endpoints ────────────────────────────────────────────────────────
@app.get("/health")
async def health_check():
    return {"status": "healthy", "service": "mem0", "isolation": "per-user"}


@app.get("/status", response_model=StatusResponse)
async def get_status():
    return StatusResponse(
        status="running",
        bucket=settings.vector_bucket_name,
        base_collection=settings.base_collection_name,
        legacy_collection=settings.legacy_collection_name,
        region=settings.aws_region,
        llm_model=settings.llm_model,
        embedder_model=settings.embedder_model,
        active_collections=list(_instances.keys()),
    )


@app.post("/add")
async def add_memory(request: AddRequest):
    try:
        m, col = get_memory(request.user_id)
        logger.info(f"Adding memory: user={request.user_id} → index={col}")
        result = m.add(
            request.messages,
            user_id=request.user_id,
            metadata=request.metadata,
        )
        return {"success": True, "user_id": request.user_id, "collection": col, "result": result}
    except Exception as e:
        logger.error(f"Error adding memory: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/search", response_model=SearchResponse)
async def search_memories(request: SearchRequest):
    try:
        m, col = get_memory(request.user_id)
        logger.info(f"Searching: user={request.user_id} → index={col}, query={request.query[:50]}")
        raw = m.search(request.query, user_id=request.user_id, limit=request.limit)
        results = raw.get("results", raw) if isinstance(raw, dict) else raw

        formatted = []
        for r in results:
            formatted.append(
                MemoryResponse(
                    id=r.get("id", ""),
                    memory=r.get("memory", r.get("text", "")),
                    metadata=r.get("metadata"),
                    score=r.get("score"),
                )
            )
        return SearchResponse(results=formatted)
    except Exception as e:
        logger.error(f"Error searching: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/get_all")
async def get_all_memories(request: GetAllRequest):
    try:
        m, col = get_memory(request.user_id)
        logger.info(f"get_all: user={request.user_id} → index={col}")
        try:
            all_memories = m.get_all(user_id=request.user_id)
        except AttributeError:
            all_memories = m.get(user_id=request.user_id)
        return {
            "success": True,
            "user_id": request.user_id,
            "collection": col,
            "memories": all_memories or [],
        }
    except Exception as e:
        logger.error(f"Error get_all: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/delete")
async def delete_memory(request: DeleteRequest):
    try:
        m, col = get_memory(request.user_id)
        logger.info(f"Deleting: id={request.memory_id} from index={col}")
        result = m.delete(memory_id=request.memory_id)
        return {"success": True, "memory_id": request.memory_id, "collection": col, "result": result}
    except Exception as e:
        logger.error(f"Error deleting: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/update")
async def update_memory(request: UpdateRequest):
    try:
        m, col = get_memory(request.user_id)
        logger.info(f"Updating: id={request.memory_id} in index={col}")
        result = m.update(memory_id=request.memory_id, data=request.data)
        return {"success": True, "memory_id": request.memory_id, "collection": col, "result": result}
    except Exception as e:
        logger.error(f"Error updating: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/reset")
async def reset_memories(user_id: str = "default"):
    try:
        m, col = get_memory(user_id)
        logger.info(f"Resetting: user={user_id} → index={col}")
        result = m.reset(user_id=user_id)
        # Remove cached instance so it gets re-created
        _instances.pop(col, None)
        return {"success": True, "user_id": user_id, "collection": col, "result": result}
    except Exception as e:
        logger.error(f"Error resetting: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ─── Migration endpoint ──────────────────────────────────────────────
@app.post("/migrate")
async def migrate_from_legacy(dry_run: bool = True):
    """
    Migrate memories from the legacy shared index (mem0-memory) to per-user indexes.
    Pass ?dry_run=false to actually perform the migration.
    """
    import json
    import boto3

    try:
        client = boto3.client("s3vectors", region_name=settings.aws_region)

        # Read all vectors from legacy index
        paginator = client.get_paginator("list_vectors")
        pages = paginator.paginate(
            vectorBucketName=settings.vector_bucket_name,
            indexName=settings.legacy_collection_name,
            returnData=True,
            returnMetadata=True,
        )

        by_user: Dict[str, list] = {}
        total = 0
        for page in pages:
            for v in page.get("vectors", []):
                total += 1
                meta = v.get("metadata", {})
                if isinstance(meta, str):
                    try:
                        meta = json.loads(meta)
                    except json.JSONDecodeError:
                        meta = {}
                uid = meta.get("user_id", "unknown")
                by_user.setdefault(uid, []).append(v)

        plan = {uid: len(vecs) for uid, vecs in by_user.items()}
        logger.info(f"Migration plan: {plan} (total={total})")

        if dry_run:
            return {
                "dry_run": True,
                "legacy_index": settings.legacy_collection_name,
                "total_memories": total,
                "plan": plan,
                "message": "Pass ?dry_run=false to execute migration",
            }

        # Execute migration: write vectors to per-user indexes
        migrated = {}
        for uid, vectors in by_user.items():
            target_col = _collection_for_user(uid)

            # Ensure target index exists
            try:
                client.get_index(vectorBucketName=settings.vector_bucket_name, indexName=target_col)
            except client.exceptions.NotFoundException:
                client.create_index(
                    vectorBucketName=settings.vector_bucket_name,
                    indexName=target_col,
                    dataType="float32",
                    dimension=settings.embedding_dims,
                    distanceMetric=settings.distance_metric,
                )
                logger.info(f"Created index: {target_col}")

            # Batch put vectors (S3 Vectors supports up to 100 per call)
            batch_size = 50
            for i in range(0, len(vectors), batch_size):
                batch = vectors[i : i + batch_size]
                vectors_to_put = []
                for v in batch:
                    entry = {
                        "key": v["key"],
                        "metadata": v.get("metadata", {}),
                    }
                    # Copy vector data
                    data = v.get("data", {})
                    if data:
                        entry["data"] = data
                    vectors_to_put.append(entry)

                client.put_vectors(
                    vectorBucketName=settings.vector_bucket_name,
                    indexName=target_col,
                    vectors=vectors_to_put,
                )

            migrated[uid] = {"count": len(vectors), "target_index": target_col}
            logger.info(f"Migrated {len(vectors)} vectors: {uid} → {target_col}")

        return {
            "dry_run": False,
            "legacy_index": settings.legacy_collection_name,
            "total_migrated": total,
            "details": migrated,
            "message": "Migration complete. Legacy index preserved (delete manually when ready).",
        }

    except Exception as e:
        logger.error(f"Migration error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8765, log_level="info")
