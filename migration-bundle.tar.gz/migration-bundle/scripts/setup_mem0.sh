#!/usr/bin/env bash
#
# setup_mem0.sh — Deploy mem0 service, create systemd unit, start service
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
BUNDLE_DIR="$(dirname "$SCRIPT_DIR")"
MEM0_EXPORT="$BUNDLE_DIR/mem0-export"
MEM0_DIR="$HOME/memory-s3vectors/mem0"
REGION="${AWS_REGION:-ap-northeast-1}"

echo "🧠 Setting up mem0 service..."

# ── Step 1: Deploy service files ──
mkdir -p "$MEM0_DIR"
cp "$MEM0_EXPORT/service-source/service.py" "$MEM0_DIR/"
echo "  ✅ Service files deployed to $MEM0_DIR"

# ── Step 2: Install Python dependencies ──
echo "  📦 Installing Python dependencies..."
pip install -q --break-system-packages mem0ai boto3 fastapi uvicorn pydantic 2>&1 | tail -2 || \
pip install -q mem0ai boto3 fastapi uvicorn pydantic 2>&1 | tail -2
echo "  ✅ Dependencies installed"

# ── Step 3: Create systemd user service ──
UNIT_DIR="$HOME/.config/systemd/user"
mkdir -p "$UNIT_DIR"

cat > "$UNIT_DIR/mem0-service.service" << EOF
[Unit]
Description=Mem0 Memory Service (S3 Vectors + Bedrock)
After=network.target

[Service]
Type=simple
WorkingDirectory=$MEM0_DIR
Environment=AWS_REGION=$REGION
ExecStart=/usr/bin/python3 -m uvicorn service:app --host 127.0.0.1 --port 8765 --log-level info
Restart=on-failure
RestartSec=5

[Install]
WantedBy=default.target
EOF

echo "  ✅ Systemd unit created"

# ── Step 4: Enable and start ──
systemctl --user daemon-reload
systemctl --user enable mem0-service 2>/dev/null
systemctl --user start mem0-service
echo "  ✅ Service started"

# ── Step 5: Wait and verify ──
echo "  ⏳ Waiting for service to be ready..."
for i in $(seq 1 10); do
  if curl -s http://127.0.0.1:8765/health >/dev/null 2>&1; then
    echo "  ✅ mem0 is healthy!"
    curl -s http://127.0.0.1:8765/health
    echo ""
    break
  fi
  sleep 1
done

if ! curl -s http://127.0.0.1:8765/health >/dev/null 2>&1; then
  echo "  ❌ mem0 failed to start. Check: journalctl --user -u mem0-service --no-pager -n 20"
  exit 1
fi

echo ""
echo "✅ mem0 setup complete!"
echo "   Service: mem0-service (systemd user)"
echo "   Endpoint: http://127.0.0.1:8765"
echo ""
echo "Next: restore memories with:"
echo "   cd $MEM0_EXPORT && python3 restore_mem0.py"
