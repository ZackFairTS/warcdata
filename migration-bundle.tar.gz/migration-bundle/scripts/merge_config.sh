#!/usr/bin/env bash
#
# merge_config.sh — Merge 3 agents into openclaw.json
#
set -euo pipefail

HOME_DIR="$HOME"
CONFIG="$HOME_DIR/.openclaw/openclaw.json"
BUDGET_DIR="$HOME_DIR/budget-demo"
OPENCLAW_DIR="$HOME_DIR/.openclaw"

if [[ ! -f "$CONFIG" ]]; then
  echo "❌ openclaw.json not found at $CONFIG"
  exit 1
fi

echo "🔧 Merging agent config into openclaw.json..."

python3 << PYEOF
import json

HOME = "$HOME_DIR"
config_path = "$CONFIG"

with open(config_path, 'r') as f:
    config = json.load(f)

# Remove existing entries for these agents (idempotent)
existing_ids = {'cfo-assistant', 'data-analyst', 'compliance-auditor'}
config['agents']['list'] = [a for a in config.get('agents', {}).get('list', []) if a.get('id') not in existing_ids]

# Add 3 agents
config['agents']['list'].extend([
    {
        "id": "cfo-assistant",
        "name": "cfo-assistant",
        "workspace": f"{HOME}/budget-demo/workspace-cfo",
        "agentDir": f"{HOME}/.openclaw/agents/cfo-assistant/agent",
        "model": {"primary": config['agents']['defaults']['model']['primary']},
        "subagents": {"allowAgents": ["data-analyst", "compliance-auditor"]}
    },
    {
        "id": "data-analyst",
        "name": "data-analyst",
        "workspace": f"{HOME}/budget-demo/workspace-analyst",
        "agentDir": f"{HOME}/.openclaw/agents/data-analyst/agent",
        "model": {"primary": config['agents']['defaults']['model']['primary']},
        "heartbeat": {"every": "30m", "target": "none", "lightContext": True, "isolatedSession": True}
    },
    {
        "id": "compliance-auditor",
        "name": "compliance-auditor",
        "workspace": f"{HOME}/budget-demo/workspace-auditor",
        "agentDir": f"{HOME}/.openclaw/agents/compliance-auditor/agent",
        "model": {"primary": config['agents']['defaults']['model']['primary']}
    }
])

# Enable agent-to-agent
a2a_allow = set(config.get('tools', {}).get('agentToAgent', {}).get('allow', []))
a2a_allow.update(['main', 'cfo-assistant', 'data-analyst', 'compliance-auditor'])
config.setdefault('tools', {})['agentToAgent'] = {
    "enabled": True,
    "allow": sorted(list(a2a_allow))
}

# Enable cross-agent session visibility
config.setdefault('tools', {})['sessions'] = {"visibility": "all"}

# Allow main to spawn sub-agents
for agent in config['agents']['list']:
    if agent['id'] == 'main':
        agent.setdefault('subagents', {})['allowAgents'] = ['cfo-assistant', 'data-analyst', 'compliance-auditor']
        break

with open(config_path, 'w') as f:
    json.dump(config, f, indent=2, ensure_ascii=False)

agents = [a['id'] for a in config['agents']['list']]
model = config['agents']['defaults']['model']['primary']
print(f"  ✅ Agents: {agents}")
print(f"  ✅ Model: {model}")
print(f"  ✅ Agent-to-agent: enabled")
PYEOF

echo ""
echo "✅ Config merge complete!"
echo "   Run 'openclaw gateway restart' to apply."
