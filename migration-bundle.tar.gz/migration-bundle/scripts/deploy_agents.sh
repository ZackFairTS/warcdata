#!/usr/bin/env bash
#
# deploy_agents.sh — Deploy agent directories, workspaces, models.json, and dependencies
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
BUNDLE_DIR="$(dirname "$SCRIPT_DIR")"
MEM0_EXPORT="$BUNDLE_DIR/mem0-export"
HOME_DIR="$HOME"
OPENCLAW_DIR="$HOME_DIR/.openclaw"
BUDGET_DIR="$HOME_DIR/budget-demo"

echo "🚀 Deploying agents and workspaces..."
echo "   Bundle: $BUNDLE_DIR"
echo "   Target: $BUDGET_DIR"
echo ""

# ── Step 1: Agent directories (SOUL.md) ──
echo "📂 Deploying agent directories..."
for agent in cfo-assistant data-analyst compliance-auditor; do
  mkdir -p "$OPENCLAW_DIR/agents/$agent/agent"
done

cp "$MEM0_EXPORT/agentdir-cfo-assistant/SOUL.md" "$OPENCLAW_DIR/agents/cfo-assistant/agent/"
cp "$MEM0_EXPORT/agentdir-data-analyst/SOUL.md" "$OPENCLAW_DIR/agents/data-analyst/agent/"
cp "$MEM0_EXPORT/agentdir-compliance-auditor/SOUL.md" "$OPENCLAW_DIR/agents/compliance-auditor/agent/"
echo "  ✅ Agent SOUL.md deployed"

# ── Step 2: Copy models.json from main agent ──
MAIN_MODELS="$OPENCLAW_DIR/agents/main/agent/models.json"
if [[ -f "$MAIN_MODELS" ]]; then
  for agent in cfo-assistant data-analyst compliance-auditor; do
    cp "$MAIN_MODELS" "$OPENCLAW_DIR/agents/$agent/agent/models.json"
  done
  echo "  ✅ models.json copied from main agent"
else
  echo "  ⚠️  models.json not found at $MAIN_MODELS"
  echo "     Agents will fail with 'No API key'. Fix: chat with main agent first to generate it, then re-run."
fi

# ── Step 3: Deploy workspaces ──
echo ""
echo "📂 Deploying workspaces..."
mkdir -p "$BUDGET_DIR"
cp -r "$MEM0_EXPORT/workspace-cfo-assistant" "$BUDGET_DIR/workspace-cfo"
cp -r "$MEM0_EXPORT/workspace-data-analyst" "$BUDGET_DIR/workspace-analyst"
cp -r "$MEM0_EXPORT/workspace-compliance-auditor" "$BUDGET_DIR/workspace-auditor"
echo "  ✅ Workspaces deployed"

# ── Step 4: Deploy shared scripts ──
echo ""
echo "📂 Deploying shared scripts..."
mkdir -p "$BUDGET_DIR/scripts"
if [[ -f "$MEM0_EXPORT/workspace-data-analyst/scripts/athena_query.py" ]]; then
  cp "$MEM0_EXPORT/workspace-data-analyst/scripts/athena_query.py" "$BUDGET_DIR/scripts/"
  echo "  ✅ athena_query.py → ~/budget-demo/scripts/"
else
  echo "  ⚠️  athena_query.py not found in bundle"
fi

# ── Step 5: Install analyst Node.js dependencies ──
echo ""
echo "📦 Installing analyst dependencies (echarts, canvas)..."
cd "$BUDGET_DIR/workspace-analyst"
if command -v npm &>/dev/null; then
  npm install --silent echarts canvas 2>&1 | tail -3
  echo "  ✅ npm dependencies installed"
else
  echo "  ⚠️  npm not found. Install Node.js, then run: cd $BUDGET_DIR/workspace-analyst && npm install echarts canvas"
fi

echo ""
echo "✅ Agent deployment complete!"
echo "   Agent dirs:  $OPENCLAW_DIR/agents/{cfo-assistant,data-analyst,compliance-auditor}"
echo "   Workspaces:  $BUDGET_DIR/workspace-{cfo,analyst,auditor}"
echo "   Scripts:     $BUDGET_DIR/scripts/"
