#!/usr/bin/env bash
#
# restore_all.sh — One-shot full migration restore
#
# Usage:
#   bash scripts/restore_all.sh [--region ap-northeast-1] [--skip-athena] [--skip-opensearch] [--skip-mem0]
#
# Runs all migration steps in the correct order:
#   Phase 1: Data Layer  (Athena → OpenSearch → mem0)
#   Phase 2: Agents      (deploy dirs, workspaces, models.json, deps)
#   Phase 3: Config      (merge openclaw.json, create S3 signer)
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
BUNDLE_DIR="$(dirname "$SCRIPT_DIR")"
REGION=""

SKIP_ATHENA=false
SKIP_OPENSEARCH=false
SKIP_MEM0=false

while [[ $# -gt 0 ]]; do
  case $1 in
    --region) REGION="$2"; shift 2 ;;
    --skip-athena) SKIP_ATHENA=true; shift ;;
    --skip-opensearch) SKIP_OPENSEARCH=true; shift ;;
    --skip-mem0) SKIP_MEM0=true; shift ;;
    -h|--help)
      echo "Usage: bash $0 [--region REGION] [--skip-athena] [--skip-opensearch] [--skip-mem0]"
      exit 0 ;;
    *) echo "Unknown arg: $1"; exit 1 ;;
  esac
done

# ═══════════════════════════════════════════════════
# Preflight: detect region
# ═══════════════════════════════════════════════════
if [[ -z "$REGION" ]]; then
  echo "🔍 No --region specified, auto-detecting..."

  # Try EC2 IMDS v2
  IMDS_TOKEN=$(curl -s -X PUT "http://169.254.169.254/latest/api/token" \
    -H "X-aws-ec2-metadata-token-ttl-seconds: 5" --connect-timeout 2 2>/dev/null || true)
  if [[ -n "$IMDS_TOKEN" ]]; then
    REGION=$(curl -s -H "X-aws-ec2-metadata-token: $IMDS_TOKEN" \
      http://169.254.169.254/latest/meta-data/placement/region --connect-timeout 2 2>/dev/null || true)
  fi

  # Try aws configure
  if [[ -z "$REGION" ]] && command -v aws &>/dev/null; then
    REGION=$(aws configure get region 2>/dev/null || true)
  fi

  # Try AWS_REGION / AWS_DEFAULT_REGION env
  if [[ -z "$REGION" ]]; then
    REGION="${AWS_REGION:-${AWS_DEFAULT_REGION:-}}"
  fi

  # Fallback
  if [[ -z "$REGION" ]]; then
    REGION="ap-northeast-1"
    echo "  ⚠️  Could not detect region, using default: $REGION"
  else
    echo "  ✅ Detected region: $REGION"
  fi
fi

export AWS_REGION="$REGION"

# ═══════════════════════════════════════════════════
# Preflight: install missing dependencies
# ═══════════════════════════════════════════════════
echo ""
echo "🔍 Checking dependencies..."

NEED_APT=()

if ! command -v unzip &>/dev/null; then
  NEED_APT+=(unzip)
fi

if ! command -v python3 &>/dev/null; then
  NEED_APT+=(python3 python3-pip)
fi

if ! command -v pip3 &>/dev/null && ! python3 -m pip --version &>/dev/null 2>&1; then
  NEED_APT+=(python3-pip)
fi

if [[ ${#NEED_APT[@]} -gt 0 ]]; then
  echo "  📦 Installing apt packages: ${NEED_APT[*]}"
  sudo apt-get update -qq && sudo apt-get install -y -qq "${NEED_APT[@]}" 2>&1 | tail -3
fi

if ! command -v aws &>/dev/null; then
  echo "  📦 Installing AWS CLI v2..."
  TMPDIR=$(mktemp -d)
  curl -sL "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "$TMPDIR/awscliv2.zip"
  unzip -q -o "$TMPDIR/awscliv2.zip" -d "$TMPDIR"
  sudo "$TMPDIR/aws/install" --update 2>&1 | tail -1
  rm -rf "$TMPDIR"
  echo "  ✅ AWS CLI installed: $(aws --version 2>&1)"
fi

echo "  ✅ All dependencies ready"
echo ""

echo "╔══════════════════════════════════════════════╗"
echo "║       OpenClaw 3-Agent Migration Restore     ║"
echo "╚══════════════════════════════════════════════╝"
echo ""
echo "Region: $REGION"
echo "Bundle: $BUNDLE_DIR"
echo ""

# ═══════════════════════════════════════════════════
# Phase 1: Data Layer
# ═══════════════════════════════════════════════════
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Phase 1: Data Layer"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# ── 1a. Athena ──
if [[ "$SKIP_ATHENA" == "false" ]]; then
  echo "▶ Step 1: Initialize Athena..."
  bash "$BUNDLE_DIR/athena-export/setup_athena.sh" --region "$REGION"
  echo ""
else
  echo "⏭ Athena: skipped"
fi

# ── 1b. OpenSearch ──
if [[ "$SKIP_OPENSEARCH" == "false" ]]; then
  echo "▶ Step 2: Ensure OpenSearch is running..."
  bash "$SCRIPT_DIR/setup_opensearch.sh"
  echo ""

  echo "▶ Step 2b: Restore OpenSearch data..."
  if curl -s localhost:9200 >/dev/null 2>&1; then
    pip install -q --break-system-packages opensearch-py 2>/dev/null || pip install -q opensearch-py 2>/dev/null
    python3 "$BUNDLE_DIR/opensearch-export/restore_opensearch.py"
  else
    echo "  ❌ OpenSearch not reachable at localhost:9200. Skipping data restore."
    echo "     Run manually: python3 $BUNDLE_DIR/opensearch-export/restore_opensearch.py"
  fi
  echo ""
else
  echo "⏭ OpenSearch: skipped"
fi

# ── 1c. mem0 ──
if [[ "$SKIP_MEM0" == "false" ]]; then
  echo "▶ Step 3: Setup and start mem0 service..."
  bash "$SCRIPT_DIR/setup_mem0.sh"
  echo ""

  echo "▶ Step 4: Restore mem0 memories..."
  cd "$BUNDLE_DIR/mem0-export"
  python3 restore_mem0.py
  echo ""
else
  echo "⏭ mem0: skipped"
fi

# ═══════════════════════════════════════════════════
# Phase 2: Agent Deployment
# ═══════════════════════════════════════════════════
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Phase 2: Agent Deployment"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

echo "▶ Step 5-9: Deploy agents, workspaces, dependencies..."
bash "$SCRIPT_DIR/deploy_agents.sh"
echo ""

# ── Post-deploy: fix Athena SKILL.md bucket name for new AWS account ──
if [[ "$SKIP_ATHENA" == "false" ]]; then
  ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text 2>/dev/null || true)
  if [[ -n "$ACCOUNT_ID" ]]; then
    ACTUAL_BUCKET=$(aws s3api list-buckets --query "Buckets[?starts_with(Name, 'openclaw-analytics-${ACCOUNT_ID}')].Name" --output text 2>/dev/null | head -1)
    SKILL_MD="$HOME/budget-demo/workspace-analyst/skills/athena-query/SKILL.md"
    if [[ -n "$ACTUAL_BUCKET" && "$ACTUAL_BUCKET" != "None" && -f "$SKILL_MD" ]]; then
      sed -i -E "s|openclaw-analytics-[0-9]+|$ACTUAL_BUCKET|g" "$SKILL_MD"
      echo "📝 Updated athena-query SKILL.md with bucket: $ACTUAL_BUCKET"
      echo ""
    fi
  fi
fi

# ═══════════════════════════════════════════════════
# Phase 3: OpenClaw Config
# ═══════════════════════════════════════════════════
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Phase 3: OpenClaw Config"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

echo "▶ Step 10: Merge openclaw.json..."
bash "$SCRIPT_DIR/merge_config.sh"
echo ""

echo "▶ Step 10b: Setup S3 presigned URL signer..."
bash "$SCRIPT_DIR/setup_s3_signer.sh"
echo ""

# ═══════════════════════════════════════════════════
# Verification
# ═══════════════════════════════════════════════════
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Verification"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

PASS=0
FAIL=0

check() {
  local label="$1"
  shift
  if "$@" >/dev/null 2>&1; then
    echo "  ✅ $label"
    ((PASS++))
  else
    echo "  ❌ $label"
    ((FAIL++))
  fi
}

check "Agent dirs exist" test -f "$HOME/.openclaw/agents/cfo-assistant/agent/SOUL.md"
check "models.json exists" test -f "$HOME/.openclaw/agents/cfo-assistant/agent/models.json"
check "Workspace CFO" test -f "$HOME/budget-demo/workspace-cfo/MEMORY.md"
check "Workspace Analyst" test -f "$HOME/budget-demo/workspace-analyst/MEMORY.md"
check "Workspace Auditor" test -f "$HOME/budget-demo/workspace-auditor/MEMORY.md"
check "athena_query.py" test -f "$HOME/budget-demo/scripts/athena_query.py"
check "S3 presign script" test -f "$HOME/budget-demo/workspace-cfo/scripts/s3_upload_and_presign.sh"
check "ECharts render" test -f "$HOME/budget-demo/workspace-analyst/scripts/echart_render.js"
check "S3 signer creds" test -f "$HOME/budget-demo/workspace-cfo/scripts/.s3_signer_creds"

if [[ "$SKIP_OPENSEARCH" == "false" ]]; then
  check "OpenSearch reachable" curl -s localhost:9200
fi
if [[ "$SKIP_MEM0" == "false" ]]; then
  check "mem0 healthy" curl -s http://127.0.0.1:8765/health
fi

echo ""
echo "Results: $PASS passed, $FAIL failed"
echo ""

if [[ $FAIL -eq 0 ]]; then
  echo "╔══════════════════════════════════════════════╗"
  echo "║          ✅ Migration complete!              ║"
  echo "╚══════════════════════════════════════════════╝"
else
  echo "╔══════════════════════════════════════════════╗"
  echo "║    ⚠️  Migration completed with warnings     ║"
  echo "╚══════════════════════════════════════════════╝"
fi

echo ""
echo "Next steps:"
echo "  1. Restart gateway:  openclaw gateway restart"
echo "  2. Verify agents:    openclaw status"
echo "  3. Test CFO agent:   Send a message to cfo-assistant"
echo ""
echo "If region/bucket differ from source, also update:"
echo "  - ~/budget-demo/workspace-analyst/skills/athena-query/SKILL.md"
echo "  - ~/budget-demo/scripts/athena_query.py (REGION variable)"
