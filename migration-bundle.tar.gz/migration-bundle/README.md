# CFO 智能助手团队 — 迁移包

## ⚡ 快速恢复（推荐）

```bash
bash scripts/restore_all.sh --region us-east-1
```

这会按顺序完成以下全部步骤。恢复完成后执行：

```bash
openclaw gateway restart
openclaw devices approve --latest   # ⚠️ 必须：批准 operator.admin 权限，否则跨 Agent 通信会报 pairing required
openclaw status
```

如果需要跳过某些步骤，可加 `--skip-athena`、`--skip-opensearch`、`--skip-mem0`。

---

## 手动分步恢复

如需逐步执行，**必须按以下顺序完成所有步骤**，不要跳过：

### Phase 1: 数据层

| 步骤 | 内容 | 脚本/文档 |
|------|------|-----------|
| **1a** | Athena 数据库 + 表 + 视图 | `bash athena-export/setup_athena.sh` → [athena-export/README.md](athena-export/README.md) |
| **1b** | OpenSearch 集群 + 知识库索引 | `bash scripts/setup_opensearch.sh` + `python3 opensearch-export/restore_opensearch.py` → [opensearch-export/RESTORE-GUIDE.md](opensearch-export/RESTORE-GUIDE.md) |
| **1c** | mem0 向量记忆服务 + 记忆恢复 | `bash scripts/setup_mem0.sh` + `python3 mem0-export/restore_mem0.py` → [mem0-export/RESTORE-GUIDE.md](mem0-export/RESTORE-GUIDE.md) |

### Phase 2: Agent 部署

| 步骤 | 内容 | 脚本/文档 |
|------|------|-----------|
| **2a** | Workspace 文件 + Agent 配置 + 注册 | `bash scripts/deploy_agents.sh` |
| **2b** | memory-s3vectors 插件 | 见 [mem0-export/IMPLEMENTATION-GUIDE.md](mem0-export/IMPLEMENTATION-GUIDE.md) |

### Phase 3: 配置

| 步骤 | 内容 | 脚本/文档 |
|------|------|-----------|
| **3a** | 合并 openclaw.json 配置 | `bash scripts/merge_config.sh`，参考 [openclaw.json.reference](openclaw.json.reference) |
| **3b** | S3 签名服务（可选） | `bash scripts/setup_s3_signer.sh` |

### Phase 4: 生效

| 步骤 | 内容 | 命令 |
|------|------|------|
| **4a** | 重启 Gateway | `openclaw gateway restart` |
| **4b** | 批准设备权限（⚠️ 必须） | `openclaw devices approve --latest` |

> ⚠️ Gateway 重启后必须执行 `openclaw devices approve --latest` 批准 `operator.admin` repair 请求，否则 `sessions_send` 跨 Agent 通信会报 `pairing required` 错误。

---

## 包含内容

```
migration-bundle/
├── README.md                    ← 你在这里（唯一入口）
├── openclaw.json.reference      ← 完整配置参考
├── scripts/                     ← 部署脚本
│   ├── restore_all.sh           ← 一键恢复（推荐）
│   ├── setup_mem0.sh
│   ├── setup_opensearch.sh
│   ├── deploy_agents.sh
│   ├── merge_config.sh
│   └── setup_s3_signer.sh
├── athena-export/               ← Athena 数据（4 张 parquet 表）
├── opensearch-export/           ← OpenSearch 知识库（43 篇文档）
└── mem0-export/                 ← mem0 记忆 + workspace + agent 配置 + 插件源码
    ├── *-export.json            ← 向量记忆导出（cfo 89条 + group-t 24条）
    ├── workspace-*/             ← 3个 agent 的 workspace 文件
    ├── agentdir-*/              ← 3个 agent 的配置（SOUL.md + models.json）
    ├── service-source/          ← mem0 HTTP 服务源码
    └── plugin-source/           ← memory-s3vectors OpenClaw 插件
```

## Agent 架构

- **cfo-assistant**（主 Agent）→ 可调用 data-analyst + compliance-auditor
- **data-analyst** → Athena 查询 + OpenSearch 知识库 + EChart 图表
- **compliance-auditor** → 合规政策检索 + 审计
- **group-t** → 团队共享记忆空间
