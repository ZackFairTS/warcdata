# OpenSearch Knowledge Base Skill

A skill for managing a hybrid search knowledge base using OpenSearch 2.11 with vector + keyword (BM25) search capabilities.

## When to Use This Skill

Use this skill when you need to:
- Build a document knowledge base with semantic search capabilities
- Index Chinese and English documents with full-text search
- Perform hybrid searches combining vector embeddings with keyword matching
- Manage a document ingestion pipeline for various file formats (md, docx, txt, pdf)
- Query company documents, reports, and knowledge bases

## Prerequisites

- OpenSearch 2.11 running locally at http://localhost:9200
- AWS credentials configured for Bedrock (for Titan embeddings)
- Python 3.8+ with required dependencies

## Installation

```bash
# Install dependencies
cd /home/ubuntu/.openclaw/workspace/skills/opensearch-knowledge/scripts
pip3 install --break-system-packages -r requirements.txt
```

## CLI Commands

### 1. Setup Index

Create the OpenSearch index with proper mappings for hybrid search:

```bash
python3 scripts/setup_index.py
```

Options:
- `--index-name` - Custom index name (default: openclaw-knowledge)
- `--dimension` - Vector dimension (default: 1024 for Titan v2)

### 2. Ingest Documents

Index documents into the knowledge base:

```bash
# Single file
python3 scripts/ingest.py /path/to/document.md

# Directory
python3 scripts/ingest.py /path/to/documents/

# With tags
python3 scripts/ingest.py document.md --tags "quarterly,finance"
```

Supported formats: .md, .docx, .txt, .pdf

### 3. Hybrid Search

Search the knowledge base with combined vector + keyword search:

```bash
# Basic search
python3 scripts/search.py "公司第三季度营收是多少"

# With custom k value
python3 scripts/search.py "财务报告" --k 20

# Show debug info
python3 scripts/search.py "投资分析" --debug
```

### 4. Management

Manage the knowledge base:

```bash
# Show index statistics
python3 scripts/manage.py stats

# List indexed documents
python3 scripts/manage.py list

# Delete by filename
python3 scripts/manage.py delete --file "2025年Q3财务报告.md"

# Clear entire index
python3 scripts/manage.py clear
```

### 5. Generate Test Documents

Create sample Chinese company documents for testing:

```bash
python3 test/generate_test_docs.py
```

### 6. End-to-End Test

Run full pipeline test:

```bash
python3 test/test_e2e.py
```

## Hybrid Search Configuration

The skill uses OpenSearch's hybrid search combining:

1. **BM25 Keyword Search**: Standard analyzer with CJK support for Chinese text
   - `standard` analyzer for English
   - `cjk` analyzer for Chinese/Japanese/Korean

2. **k-NN Vector Search**: Dense vector embeddings via Bedrock Titan v2
   - Model: `amazon.titan-embed-text-v2:0`
   - Dimension: 1024
   - Similarity: cosine

3. **Hybrid Query**: Combines both using `hybrid` query or `bool` with `function_score`

### Index Mapping

```json
{
  "settings": {
    "index.knn": true,
    "analysis": {
      "analyzer": {
        "cjk_analyzer": {
          "type": "standard",
          "stopwords": "_cjk_stops_"
        }
      }
    }
  },
  "mappings": {
    "properties": {
      "content": {
        "type": "text",
        "analyzer": "standard",
        "fields": {
          "cjk": { "type": "text", "analyzer": "cjk_analyzer" }
        }
      },
      "embedding": {
        "type": "knn_vector",
        "dimension": 1024,
        "method": { "engine": "nmslib", "space_type": "cosinesimil", "function": "l2" }
      },
      "filename": { "type": "keyword" },
      "file_type": { "type": "keyword" },
      "chunk_index": { "type": "integer" },
      "created_at": { "type": "date" },
      "tags": { "type": "keyword" }
    }
  }
}
```

## Usage Examples

### Building a Knowledge Base

```bash
# 1. Setup index
python3 scripts/setup_index.py

# 2. Generate test documents
python3 test/generate_test_docs.py

# 3. Ingest documents
python3 scripts/ingest.py test/docs/

# 4. Search
python3 scripts/search.py "2025年营收情况"
```

### Searching Financial Reports

```bash
# Find Q3 financial data
python3 scripts/search.py "第三季度营收 利润"

# Find budget information
python3 scripts/search.py "年度预算 部门费用"

# Find investment analysis
python3 scripts/search.py "投资回报 收益率"
```

## Environment Variables

- `OPENSEARCH_URL` - OpenSearch endpoint (default: http://localhost:9200)
- `OPENSEARCH_USERNAME` - Auth username (default: admin)
- `OPENSEARCH_PASSWORD` - Auth password (default: admin)
- `AWS_REGION` - AWS region for Bedrock (default: us-east-1)
- `INDEX_NAME` - Index name (default: openclaw-knowledge)

## Troubleshooting

### Connection Issues

If OpenSearch is not accessible:
```bash
# Check if OpenSearch is running
curl http://localhost:9200

# Check Docker containers
docker ps | grep opensearch
```

### Embedding Generation Issues

If Bedrock calls fail:
- Verify AWS credentials are configured (`aws sts get-caller-identity`)
- Ensure Titan Embed v2 is available in your region
- Check IAM permissions for bedrock:InvokeModel

### Search Issues

If search returns no results:
- Verify documents were ingested (`python3 scripts/manage.py list`)
- Check index health (`python3 scripts/manage.py stats`)
- Try pure keyword search: use `--debug` to see query details