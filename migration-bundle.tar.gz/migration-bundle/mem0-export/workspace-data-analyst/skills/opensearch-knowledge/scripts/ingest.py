import os
import sys
import argparse
from datetime import datetime, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from opensearch_client import OpenSearchClient
from document_parser import parse_document, get_file_type, chunk_text, get_filename
from embedder import get_embedder

INDEX_NAME = "openclaw-knowledge"


def ingest_file(file_path: str, client: OpenSearchClient, embedder, tags: list = None):
    if not os.path.exists(file_path):
        print(f"File not found: {file_path}")
        return 0
    
    filename = get_filename(file_path)
    file_type = get_file_type(file_path)
    
    print(f"Parsing {filename}...")
    content = parse_document(file_path)
    
    print(f"Chunking content ({len(content)} chars)...")
    chunks = chunk_text(content, chunk_size=500, overlap=100)
    print(f"Created {len(chunks)} chunks")
    
    print("Generating embeddings...")
    embeddings = embedder.embed_batch(chunks)
    
    documents = []
    created_at = datetime.now(timezone.utc).isoformat()
    
    for i, (chunk, embedding) in enumerate(zip(chunks, embeddings)):
        doc = {
            "content": chunk,
            "embedding": embedding,
            "filename": filename,
            "file_type": file_type,
            "chunk_index": i,
            "created_at": created_at,
            "tags": tags or []
        }
        doc_id = f"{filename}_{i}"
        doc["id"] = doc_id
        documents.append(doc)
    
    print(f"Indexing {len(documents)} documents...")
    result = client.bulk_index(documents)
    print(f"Indexed {result['success']} documents, {result['failed']} failed")
    
    return len(documents)


def ingest_directory(dir_path: str, client: OpenSearchClient, embedder, tags: list = None):
    if not os.path.isdir(dir_path):
        print(f"Directory not found: {dir_path}")
        return 0
    
    supported_exts = ['.md', '.txt', '.docx', '.pdf']
    files = []
    
    for root, _, filenames in os.walk(dir_path):
        for filename in filenames:
            ext = os.path.splitext(filename)[1].lower()
            if ext in supported_exts:
                files.append(os.path.join(root, filename))
    
    print(f"Found {len(files)} files to ingest")
    
    total = 0
    for file_path in files:
        try:
            count = ingest_file(file_path, client, embedder, tags)
            total += count
        except Exception as e:
            print(f"Error ingesting {file_path}: {e}")
    
    return total


def main():
    parser = argparse.ArgumentParser(description="Ingest documents into OpenSearch")
    parser.add_argument("path", help="File or directory path")
    parser.add_argument("--tags", nargs="*", default=[], help="Tags for documents")
    parser.add_argument("--mock", action="store_true", help="Use mock embedder (no Bedrock)")
    parser.add_argument("--index-name", default=INDEX_NAME, help="Index name")
    args = parser.parse_args()
    
    client = OpenSearchClient()
    client.index_name = args.index_name
    
    embedder = get_embedder(use_mock=args.mock)
    
    if os.path.isdir(args.path):
        total = ingest_directory(args.path, client, embedder, args.tags)
    else:
        total = ingest_file(args.path, client, embedder, args.tags)
    
    print(f"\nTotal documents indexed: {total}")


if __name__ == "__main__":
    main()