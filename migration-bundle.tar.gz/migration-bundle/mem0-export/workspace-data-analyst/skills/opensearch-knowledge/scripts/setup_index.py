import argparse
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from opensearch_client import OpenSearchClient

INDEX_NAME = "openclaw-knowledge"
DIMENSION = 1024

INDEX_SETTINGS = {
    "settings": {
        "index": {
            "knn": True,
            "number_of_shards": 1,
            "number_of_replicas": 0
        },
        "analysis": {
            "analyzer": {
                "cjk_analyzer": {
                    "type": "standard",
                    "stopwords": "_cjk_stops_"
                }
            }
        }
    },
    "mappings": {
        "properties": {
            "content": {
                "type": "text",
                "analyzer": "standard",
                "fields": {
                    "cjk": {
                        "type": "text",
                        "analyzer": "cjk_analyzer"
                    }
                }
            },
            "embedding": {
                "type": "knn_vector",
                "dimension": DIMENSION,
                "method": {
                    "name": "hnsw",
                    "engine": "lucene",
                    "space_type": "l2",
                    "parameters": {
                        "ef_construction": 128,
                        "m": 16
                    }
                }
            },
            "filename": {"type": "keyword"},
            "file_type": {"type": "keyword"},
            "chunk_index": {"type": "integer"},
            "created_at": {"type": "date"},
            "tags": {"type": "keyword"},
            "title": {"type": "text", "analyzer": "standard"}
        }
    }
}


def setup_index(client: OpenSearchClient, index_name: str, dimension: int):
    if client.index_exists(index_name):
        print(f"Index '{index_name}' already exists. Recreating...")
        client.delete_index(index_name)
        print(f"Deleted index '{index_name}'")

    if dimension != DIMENSION:
        INDEX_SETTINGS["mappings"]["properties"]["embedding"]["dimension"] = dimension
    
    print(f"Creating index '{index_name}' with dimension {dimension}...")
    client.create_index(index_name, INDEX_SETTINGS)
    print(f"Index '{index_name}' created successfully!")
    
    client.wait_for_index_ready(index_name)
    print(f"Index is ready for use.")


def main():
    parser = argparse.ArgumentParser(description="Setup OpenSearch index for hybrid search")
    parser.add_argument("--index-name", default=INDEX_NAME, help="Index name")
    parser.add_argument("--dimension", type=int, default=DIMENSION, help="Vector dimension (default: 1024)")
    args = parser.parse_args()
    
    client = OpenSearchClient()
    setup_index(client, args.index_name, args.dimension)


if __name__ == "__main__":
    main()