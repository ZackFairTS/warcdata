import os
import re
from typing import List, Optional


def parse_markdown(file_path: str) -> str:
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    return content


def parse_text(file_path: str) -> str:
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    return content


def parse_docx(file_path: str) -> str:
    try:
        from docx import Document
        doc = Document(file_path)
        paragraphs = []
        for para in doc.paragraphs:
            if para.text.strip():
                paragraphs.append(para.text)
        return '\n'.join(paragraphs)
    except ImportError:
        print("python-docx not installed. Install with: pip install python-docx")
        raise


def parse_pdf(file_path: str) -> str:
    try:
        from PyPDF2 import PdfReader
        reader = PdfReader(file_path)
        text_parts = []
        for page in reader.pages:
            text = page.extract_text()
            if text:
                text_parts.append(text)
        return '\n'.join(text_parts)
    except ImportError:
        print("PyPDF2 not installed. Install with: pip install PyPDF2")
        raise


def parse_document(file_path: str) -> str:
    ext = os.path.splitext(file_path)[1].lower()
    
    if ext == '.md':
        return parse_markdown(file_path)
    elif ext == '.txt':
        return parse_text(file_path)
    elif ext == '.docx':
        return parse_docx(file_path)
    elif ext == '.pdf':
        return parse_pdf(file_path)
    else:
        raise ValueError(f"Unsupported file type: {ext}")


def get_file_type(file_path: str) -> str:
    ext = os.path.splitext(file_path)[1].lower()
    type_map = {
        '.md': 'markdown',
        '.txt': 'text',
        '.docx': 'docx',
        '.pdf': 'pdf'
    }
    return type_map.get(ext, 'unknown')


def chunk_text(text: str, chunk_size: int = 500, overlap: int = 100) -> List[str]:
    try:
        import tiktoken
        enc = tiktoken.get_encoding("cl100k_base")
        tokens = enc.encode(text)
    except ImportError:
        tokens = text.split()
    
    chunks = []
    step = chunk_size - overlap
    
    for i in range(0, len(tokens), step):
        chunk_tokens = tokens[i:i + chunk_size]
        
        try:
            chunk_text = enc.decode(chunk_tokens)
        except ImportError:
            chunk_text = ' '.join(chunk_tokens)
        
        if chunk_text.strip():
            chunks.append(chunk_text)
    
    if not chunks and text.strip():
        chunks.append(text[:1000])
    
    return chunks


def get_filename(file_path: str) -> str:
    return os.path.basename(file_path)