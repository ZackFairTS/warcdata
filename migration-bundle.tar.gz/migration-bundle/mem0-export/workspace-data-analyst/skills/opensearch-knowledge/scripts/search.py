import os
import sys
import argparse
import json

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from opensearch_client import OpenSearchClient
from embedder import get_embedder

INDEX_NAME = "openclaw-knowledge"
USE_MOCK = False


def build_hybrid_query(query_text: str, k: int = 10, use_mock: bool = False):
    embedder = get_embedder(use_mock=use_mock)
    
    try:
        query_embedding = embedder.embed(query_text)
        has_embedding = True
    except Exception as e:
        print(f"Warning: Could not generate embedding: {e}")
        print("Using keyword-only search")
        has_embedding = False
    
    if has_embedding:
        hybrid_query = {
            "query": {
                "hybrid": {
                    "queries": [
                        {
                            "match": {
                                "content": {
                                    "query": query_text
                                }
                            }
                        },
                        {
                            "knn": {
                                "embedding": {
                                    "vector": query_embedding,
                                    "k": k
                                }
                            }
                        }
                    ]
                }
            },
            "size": k,
            "highlight": {
                "fields": {
                    "content": {
                        "pre_tags": ["<mark>"],
                        "post_tags": ["</mark>"]
                    }
                }
            }
        }
    else:
        hybrid_query = {
            "query": {
                "match": {
                    "content": {
                        "query": query_text
                    }
                }
            },
            "size": k,
            "highlight": {
                "fields": {
                    "content": {
                        "pre_tags": ["<mark>"],
                        "post_tags": ["</mark>"]
                    }
                }
            }
        }
    
    return hybrid_query


def build_fallback_query(query_text: str, k: int = 10, use_mock: bool = False):
    embedder = get_embedder(use_mock=use_mock)
    
    try:
        query_embedding = embedder.embed(query_text)
        has_embedding = True
    except Exception:
        has_embedding = False
    
    if has_embedding:
        query = {
            "query": {
                "bool": {
                    "should": [
                        {
                            "match": {
                                "content": query_text
                            }
                        },
                        {
                            "knn": {
                                "embedding": {
                                    "vector": query_embedding,
                                    "k": k
                                }
                            }
                        }
                    ]
                }
            },
            "size": k,
            "highlight": {
                "fields": {
                    "content": {
                        "pre_tags": ["<mark>"],
                        "post_tags": ["</mark>"]
                    }
                }
            }
        }
    else:
        query = {
            "query": {
                "match": {
                    "content": query_text
                }
            },
            "size": k,
            "highlight": {
                "fields": {
                    "content": {}
                }
            }
        }
    
    return query


def search(query_text: str, client: OpenSearchClient, k: int = 10, debug: bool = False, use_mock: bool = False):
    try:
        query = build_hybrid_query(query_text, k, use_mock)
    except Exception as e:
        print(f"Hybrid query failed: {e}")
        print("Using fallback query...")
        query = build_fallback_query(query_text, k, use_mock)
    
    if debug:
        print("\nQuery:")
        print(json.dumps(query, indent=2, ensure_ascii=False))
    
    try:
        response = client.search(query, size=k)
    except Exception as e:
        print(f"Search failed: {e}")
        print("Trying fallback query...")
        query = build_fallback_query(query_text, k, use_mock)
        if debug:
            print("\nFallback Query:")
            print(json.dumps(query, indent=2, ensure_ascii=False))
        response = client.search(query, size=k)
    
    return response


def format_results(response: dict) -> str:
    hits = response.get("hits", {})
    total = hits.get("total", {}).get("value", 0)
    
    if total == 0:
        return "No results found."
    
    results = []
    results.append(f"\n{'='*60}")
    results.append(f"Found {total} results")
    results.append(f"{'='*60}\n")
    
    for i, hit in enumerate(hits.get("hits", []), 1):
        source = hit.get("_source", {})
        score = hit.get("_score", 0)
        
        filename = source.get("filename", "unknown")
        chunk_index = source.get("chunk_index", 0)
        content = source.get("content", "")
        
        highlights = hit.get("highlight", {}).get("content", [])
        highlighted = highlights[0] if highlights else content[:200] + "..."
        
        results.append(f"Result {i} (score: {score:.4f})")
        results.append(f"  File: {filename} (chunk {chunk_index})")
        results.append(f"  ---")
        results.append(f"  {highlighted}")
        results.append("")
    
    return "\n".join(results)


def main():
    parser = argparse.ArgumentParser(description="Search OpenSearch knowledge base")
    parser.add_argument("query", help="Search query text")
    parser.add_argument("--k", type=int, default=10, help="Number of results (default: 10)")
    parser.add_argument("--debug", action="store_true", help="Print query JSON")
    parser.add_argument("--mock", action="store_true", help="Use mock embedder")
    parser.add_argument("--index-name", default=INDEX_NAME, help="Index name")
    args = parser.parse_args()
    
    client = OpenSearchClient()
    client.index_name = args.index_name
    
    response = search(args.query, client, k=args.k, debug=args.debug, use_mock=args.mock)
    print(format_results(response))


if __name__ == "__main__":
    main()