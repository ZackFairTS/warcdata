import os
from opensearchpy import OpenSearch

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass


class OpenSearchClient:
    def __init__(self):
        self.url = os.getenv("OPENSEARCH_URL", "http://localhost:9200")
        self.username = os.getenv("OPENSEARCH_USERNAME", "admin")
        self.password = os.getenv("OPENSEARCH_PASSWORD", "admin")
        self.index_name = os.getenv("INDEX_NAME", "openclaw-knowledge")
        
        # Check if security is disabled (no auth required)
        disable_security = os.getenv("DISABLE_SECURITY_PLUGIN", "").lower() == "true"
        
        client_kwargs = {
            "hosts": [self.url],
            "use_ssl": False,
            "verify_certs": False,
            "ssl_show_warn": False
        }
        
        # Only add http_auth if security is enabled
        if not disable_security:
            client_kwargs["http_auth"] = (self.username, self.password)
        
        self.client = OpenSearch(**client_kwargs)
    
    @property
    def index(self):
        return self.index_name
    
    def index_exists(self, index_name: str) -> bool:
        return self.client.indices.exists(index=index_name)
    
    def create_index(self, index_name: str, settings: dict):
        self.client.indices.create(index=index_name, body=settings)
    
    def delete_index(self, index_name: str):
        if self.index_exists(index_name):
            self.client.indices.delete(index=index_name)
    
    def wait_for_index_ready(self, index_name: str, timeout: int = 30):
        import time
        for _ in range(timeout):
            try:
                status = self.client.cluster.health(index=index_name)
                if status["status"] in ["green", "yellow"]:
                    return
            except Exception:
                pass
            time.sleep(1)
        raise TimeoutError(f"Index {index_name} did not become ready in {timeout}s")
    
    def index_document(self, doc_id: str, document: dict):
        return self.client.index(index=self.index_name, id=doc_id, body=document)
    
    def bulk_index(self, documents: list):
        from opensearchpy.helpers import bulk
        
        def generate_actions():
            for doc in documents:
                yield {
                    "_index": self.index_name,
                    "_id": doc.get("id"),
                    "_source": doc
                }
        
        success, failed = bulk(self.client, generate_actions())
        return {"success": success, "failed": failed}
    
    def search(self, query: dict, size: int = 10):
        return self.client.search(index=self.index_name, body=query, size=size)
    
    def delete_by_query(self, query: dict):
        return self.client.delete_by_query(index=self.index_name, body=query)
    
    def get_stats(self):
        return self.client.indices.stats(index=self.index_name)
    
    def get_doc_count(self):
        return self.client.count(index=self.index_name)["count"]
    
    def scroll_all(self, query: dict = None):
        if query is None:
            query = {"query": {"match_all": {}}}
        import time
        page = self.client.search(index=self.index_name, body=query, scroll="1m", size=100)
        scroll_id = page["_scroll_id"]
        results = page["hits"]["hits"]
        
        while page["hits"]["hits"]:
            page = self.client.scroll(scroll_id=scroll_id, scroll="1m")
            results.extend(page["hits"]["hits"])
            time.sleep(0.1)
        
        try:
            self.client.clear_scroll(scroll_id=scroll_id)
        except Exception:
            pass
        return results