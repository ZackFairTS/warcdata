import os
import sys
import subprocess

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
SKILL_DIR = os.path.dirname(SCRIPT_DIR)
SCRIPTS_DIR = os.path.join(SKILL_DIR, "scripts")
TEST_DOCS_DIR = os.path.join(SCRIPT_DIR, "docs")


def run_command(cmd, cwd=None):
    print(f"\n$ {cmd}")
    result = subprocess.run(cmd, shell=True, cwd=cwd or SCRIPTS_DIR, capture_output=True, text=True)
    if result.stdout:
        print(result.stdout)
    if result.stderr:
        print(f"STDERR: {result.stderr}")
    return result.returncode == 0


def main():
    print("=" * 60)
    print("OpenSearch Knowledge Base - End-to-End Test")
    print("=" * 60)
    
    tests_passed = 0
    tests_failed = 0
    
    print("\n[1/5] Generating test documents...")
    if run_command("python3 generate_test_docs.py", cwd=SCRIPT_DIR):
        print("✓ Test documents generated")
        tests_passed += 1
    else:
        print("✗ Failed to generate test documents")
        tests_failed += 1
        return
    
    print("\n[2/5] Setting up index...")
    if run_command("python3 setup_index.py"):
        print("✓ Index created")
        tests_passed += 1
    else:
        print("✗ Failed to create index")
        tests_failed += 1
        return
    
    print("\n[3/5] Ingesting documents with mock embedder...")
    if run_command(f"python3 ingest.py {TEST_DOCS_DIR} --mock"):
        print("✓ Documents ingested")
        tests_passed += 1
    else:
        print("✗ Failed to ingest documents")
        tests_failed += 1
        return
    
    print("\n[4/5] Checking index stats...")
    if run_command("python3 manage.py stats"):
        print("✓ Stats retrieved")
        tests_passed += 1
    else:
        print("✗ Failed to get stats")
        tests_failed += 1
    
    print("\n[5/5] Running hybrid search...")
    if run_command('python3 search.py "第三季度营收" --mock'):
        print("✓ Search completed")
        tests_passed += 1
    else:
        print("✗ Search failed")
        tests_failed += 1
    
    print("\n" + "=" * 60)
    print(f"Tests passed: {tests_passed}")
    print(f"Tests failed: {tests_failed}")
    print("=" * 60)
    
    if tests_failed == 0:
        print("\n✓ All tests passed!")
        return 0
    else:
        print(f"\n✗ {tests_failed} test(s) failed")
        return 1


if __name__ == "__main__":
    sys.exit(main())