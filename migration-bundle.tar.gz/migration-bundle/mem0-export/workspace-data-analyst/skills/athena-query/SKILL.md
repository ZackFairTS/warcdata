---
name: athena-query
description: |
  Query budget data via AWS Athena. Use this skill when CFO needs quick budget queries,
  variance analysis, or department performance checks.
  触发词：Athena查询、预算查询、SQL查询、超支分析、部门报表
---

# Athena Budget Query Skill

## Configuration
- Database: `openclaw_analytics`
- Region: `us-east-1`
- S3 Bucket: `openclaw-analytics-us-east-1-{account_id}`
- Output: `s3://openclaw-analytics-us-east-1-{account_id}/athena-results/`

## Quick Query Helper
```bash
python3 /home/ubuntu/budget-demo/scripts/athena_query.py "SELECT ..."
```

## Available Tables

### budget_summary
Quarterly budget vs actual by department
```sql
SELECT quarter, department, budget, actual, variance, variance_rate 
FROM budget_summary 
ORDER BY variance_rate DESC
```

### budget_actuals
Monthly spending by department/category
```sql
SELECT quarter, department, category, month, budget, actual, variance 
FROM budget_actuals 
WHERE quarter = 'Q3'
```

### budget_plans
Planned budget by dept/category/month
```sql
SELECT * FROM budget_plans WHERE department = '研发部'
```

### department_info
Department metadata
```sql
SELECT department, head, headcount, q3_budget, q3_actual, q3_variance_rate 
FROM department_info
```

## Useful Views

### v_budget_variance
Variance analysis with percentage
```sql
SELECT * FROM v_budget_variance WHERE variance > 0 ORDER BY variance_pct DESC
```

### v_department_trend
Q1-Q3 trend by department
```sql
SELECT * FROM v_department_trend ORDER BY department, quarter
```

### v_cost_breakdown
Cost category breakdown
```sql
SELECT * FROM v_cost_breakdown WHERE quarter = 'Q3' ORDER BY total_actual DESC
```

### v_overrun_alert
Departments exceeding 10% variance
```sql
SELECT * FROM v_overrun_alert
```

## Common Queries

### Q3各部門超支情況
```sql
SELECT department, budget, actual, variance, variance_rate 
FROM budget_summary WHERE quarter = 'Q3' ORDER BY variance_rate DESC
```

### 研發部月度趨勢
```sql
SELECT month, category, budget, actual, variance 
FROM budget_actuals WHERE department = '研發部' AND quarter = 'Q3'
```

### 超支預警部門
```sql
SELECT * FROM v_overrun_alert
```

### 成本類別分析
```sql
SELECT category, SUM(actual) as total FROM budget_actuals 
WHERE quarter = 'Q3' GROUP BY category ORDER BY total DESC
```

## AWS CLI Alternative
```bash
aws athena start-query-execution \
  --query-string "SELECT * FROM budget_summary WHERE quarter='Q3'" \
  --query-execution-context Database=openclaw_analytics \
  --result-configuration OutputLocation=s3://openclaw-analytics-us-east-1-${ACCOUNT_ID}/athena-results/ \
  --region us-east-1
```
