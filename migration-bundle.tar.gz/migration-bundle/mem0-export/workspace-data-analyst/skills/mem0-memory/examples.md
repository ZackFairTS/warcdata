# 记忆测试示例

## 添加分析发现
```bash
python3 scripts/memory_manager.py add "Q3研发部超支18%，主要原因是新产品研发投入增加，预计Q4会持续"
python3 scripts/memory_manager.py add "用户特别关注研发部和市场部的预算执行情况"
python3 scripts/memory_manager.py add "供应链部门9月份成本控制有显著改善，从15%超支降到9%"
```

## 搜索记忆
```bash
python3 scripts/memory_manager.py search "研发部"
python3 scripts/memory_manager.py search "超支"
python3 scripts/memory_manager.py search "用户偏好"
```

## 查看所有记忆
```bash
python3 scripts/memory_manager.py list
```