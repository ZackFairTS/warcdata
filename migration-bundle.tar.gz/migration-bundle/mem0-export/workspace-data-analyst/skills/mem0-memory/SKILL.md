---
name: mem0-memory
description: |
  财务数据分析师的长期记忆管理工具。基于 mem0 + S3 Vectors，用于存储和检索分析洞察、数据发现、用户偏好等。
  
  **当以下情况时使用此 Skill**:
  (1) 需要记住重要的数据分析发现
  (2) 需要存储用户的分析偏好和关注点
  (3) 需要回忆之前的分析结论和趋势
  (4) 用户提到"记住"、"保存"、"回忆"、"之前分析过"
  (5) 跨会话的数据洞察需要持久化
---

# Mem0 Memory Management Skill

老陈的专业记忆系统，基于 mem0 + AWS S3 Vectors。

## 配置要求

### mem0 配置
```python
config = {
    "vector_store": {
        "provider": "s3vectors",
        "config": {
            "vector_bucket_name": "openclaw-memory-vectors",
            "collection_name": "analyst-memory",
            "embedding_model_dims": 1024,
            "distance_metric": "cosine",
            "region_name": "ap-northeast-1"
        }
    },
    "llm": {
        "provider": "aws_bedrock",
        "config": {
            "model": "anthropic.claude-haiku-4-5-20251001-v1:0",
            "temperature": 0.1
        }
    },
    "embedder": {
        "provider": "aws_bedrock",
        "config": {
            "model": "amazon.titan-embed-text-v2:0",
            "embedding_dims": 1024
        }
    }
}
```

## 记忆类型

### 1. 数据发现记忆
- 预算超支趋势
- 部门异常指标
- 成本结构变化

### 2. 用户偏好记忆
- 关注的部门
- 偏好的分析维度
- 常用的查询模式

### 3. 分析洞察记忆
- 关键分析结论
- 预测结果
- 建议措施

## 核心命令

### 记忆管理脚本
```bash
python3 /home/ubuntu/budget-demo/workspace-analyst/skills/mem0-memory/scripts/memory_manager.py
```

### 快速使用
```bash
# 添加记忆
python3 scripts/memory_manager.py add "研发部Q3超支18%，主要由于新项目投入增加"

# 搜索记忆
python3 scripts/memory_manager.py search "研发部超支"

# 获取所有记忆
python3 scripts/memory_manager.py list

# 重置记忆（危险操作）
python3 scripts/memory_manager.py reset
```

## 工作流程

1. **分析过程中**：自动记录重要发现
2. **用户交互**：记住用户关注点和偏好
3. **跨会话**：回忆之前的分析结论
4. **数据更新**：更新过时的记忆

## 记忆搜索策略

- 使用语义搜索找相关记忆
- 按时间戳排序最近记忆
- 按相关度评分排序
- 支持多维度过滤（部门、时间、类型）

## 自动记忆触发

当出现以下情况时，自动添加记忆：
- 发现显著的数据异常（>10%偏差）
- 用户询问特定部门或指标
- 生成重要分析结论
- 用户表达特殊偏好

## 注意事项

- 记忆不包含敏感财务细节
- 重点记录趋势和洞察，不是原始数据
- 定期清理过时记忆
- 保护用户隐私信息