#!/usr/bin/env python3
"""
athena_query.py — Execute SQL on Athena and print results as a table.
Usage: python3 athena_query.py "SELECT ..."
"""
import sys
import time
import json
import boto3

DATABASE = "openclaw_analytics"
REGION = "us-east-1"

def get_output_location():
    sts = boto3.client("sts", region_name=REGION)
    account_id = sts.get_caller_identity()["Account"]
    return f"s3://openclaw-analytics-us-east-1-{account_id}/athena-results/"

def run_query(sql):
    client = boto3.client("athena", region_name=REGION)
    output = get_output_location()

    resp = client.start_query_execution(
        QueryString=sql,
        QueryExecutionContext={"Database": DATABASE},
        ResultConfiguration={"OutputLocation": output},
    )
    qid = resp["QueryExecutionId"]

    while True:
        status = client.get_query_execution(QueryExecutionId=qid)
        state = status["QueryExecution"]["Status"]["State"]
        if state in ("SUCCEEDED",):
            break
        if state in ("FAILED", "CANCELLED"):
            reason = status["QueryExecution"]["Status"].get("StateChangeReason", "unknown")
            print(f"Query {state}: {reason}", file=sys.stderr)
            sys.exit(1)
        time.sleep(0.5)

    results = client.get_query_results(QueryExecutionId=qid)
    rows = results["ResultSet"]["Rows"]
    if not rows:
        print("No results.")
        return

    headers = [col["VarCharValue"] for col in rows[0]["Data"]]
    print("\t".join(headers))
    print("\t".join(["---"] * len(headers)))
    for row in rows[1:]:
        vals = [col.get("VarCharValue", "") for col in row["Data"]]
        print("\t".join(vals))

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(f"Usage: {sys.argv[0]} \"SQL query\"", file=sys.stderr)
        sys.exit(1)
    run_query(sys.argv[1])
