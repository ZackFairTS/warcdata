const { createCanvas } = require('canvas');
const echarts = require('echarts');
const fs = require('fs');

function render(option, outPath, w=1200, h=700) {
  const canvas = createCanvas(w, h);
  const chart = echarts.init(canvas, null, { width: w, height: h });
  chart.setOption(option);
  fs.writeFileSync(outPath, canvas.toBuffer('image/png'));
  chart.dispose();
}

// === 图1: Q1-Q3 各部门预算执行趋势 ===
render({
  backgroundColor: '#fff',
  title: { text: '2026年 Q1-Q3 各部门预算超支率趋势', left: 'center', top: 10,
    textStyle: { fontSize: 20, fontWeight: 'bold', color: '#333' } },
  tooltip: { trigger: 'axis', formatter: '{b}<br/>{a0}: {c0}%<br/>{a1}: {c1}%<br/>{a2}: {c2}%' },
  legend: { data: ['研发部', '市场部', '供应链'], top: 45 },
  grid: { top: 90, left: 80, right: 60, bottom: 60 },
  xAxis: { type: 'category', data: ['Q1', 'Q2', 'Q3'], axisLabel: { fontSize: 15 } },
  yAxis: { type: 'value', name: '超支率（%）', axisLabel: { formatter: '{value}%', fontSize: 13 },
    nameTextStyle: { fontSize: 14 } },
  series: [
    { name: '研发部', type: 'line', data: [5, 12, 18], symbol: 'circle', symbolSize: 10,
      lineStyle: { width: 3 }, itemStyle: { color: '#ee6666' },
      label: { show: true, formatter: '{c}%', fontSize: 13, fontWeight: 'bold' },
      markPoint: { data: [{ type: 'max', name: '最高' }] } },
    { name: '市场部', type: 'line', data: [5, 10, 15], symbol: 'circle', symbolSize: 10,
      lineStyle: { width: 3 }, itemStyle: { color: '#fac858' },
      label: { show: true, formatter: '{c}%', fontSize: 13 } },
    { name: '供应链', type: 'line', data: [5, 12.8, 7.3], symbol: 'circle', symbolSize: 10,
      lineStyle: { width: 3 }, itemStyle: { color: '#91cc75' },
      label: { show: true, formatter: '{c}%', fontSize: 13 } }
  ]
}, '/tmp/chart1_trend.png');

// === 图2: Q3 预算 vs 实际 对比 ===
render({
  backgroundColor: '#fff',
  title: { text: 'Q3 各部门预算 vs 实际支出', subtext: '单位：万元',
    left: 'center', top: 10,
    textStyle: { fontSize: 20, fontWeight: 'bold' },
    subtextStyle: { fontSize: 13, color: '#888' } },
  tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
  legend: { data: ['预算', '实际支出', '超支额'], top: 55 },
  grid: { top: 100, left: 100, right: 60, bottom: 60 },
  xAxis: { type: 'category', data: ['研发部', '市场部', '供应链'],
    axisLabel: { fontSize: 15 } },
  yAxis: { type: 'value', name: '金额（万元）', axisLabel: { fontSize: 13 },
    nameTextStyle: { fontSize: 14 } },
  series: [
    { name: '预算', type: 'bar', data: [2000, 1500, 3500],
      itemStyle: { color: '#5470c6', borderRadius: [4,4,0,0] },
      label: { show: true, position: 'top', fontSize: 12 } },
    { name: '实际支出', type: 'bar', data: [2360, 1725, 3755],
      itemStyle: { color: '#ee6666', borderRadius: [4,4,0,0] },
      label: { show: true, position: 'top', fontSize: 12 } },
    { name: '超支额', type: 'bar', data: [360, 225, 255],
      itemStyle: { color: '#fac858', borderRadius: [4,4,0,0] },
      label: { show: true, position: 'top', fontSize: 12, formatter: '+{c}' } }
  ]
}, '/tmp/chart2_budget_vs_actual.png');

// === 图3: Q3 成本结构饼图 ===
render({
  backgroundColor: '#fff',
  title: { text: 'Q3 成本结构分布', left: 'center', top: 10,
    textStyle: { fontSize: 20, fontWeight: 'bold' } },
  tooltip: { trigger: 'item', formatter: '{b}: {c}万元 ({d}%)' },
  legend: { orient: 'vertical', left: 20, top: 60, fontSize: 13 },
  series: [{
    type: 'pie', radius: ['35%', '65%'], center: ['58%', '55%'],
    itemStyle: { borderRadius: 8, borderColor: '#fff', borderWidth: 2 },
    label: { fontSize: 13, formatter: '{b}\n{d}%' },
    data: [
      { value: 2070, name: '物流成本', itemStyle: { color: '#5470c6' } },
      { value: 1380, name: '人力成本', itemStyle: { color: '#ee6666' } },
      { value: 1175, name: '库存成本', itemStyle: { color: '#91cc75' } },
      { value: 1035, name: '广告投放', itemStyle: { color: '#fac858' } },
      { value: 750, name: '项目成本', itemStyle: { color: '#73c0de' } },
      { value: 510, name: '采购成本', itemStyle: { color: '#3ba272' } },
      { value: 500, name: '活动费用', itemStyle: { color: '#fc8452' } },
      { value: 230, name: '设备采购', itemStyle: { color: '#9a60b4' } },
      { value: 190, name: 'KOL合作', itemStyle: { color: '#ea7ccc' } }
    ]
  }]
}, '/tmp/chart3_cost_pie.png');

console.log('✅ 3张图表全部生成完成');
