/**
 * OpenClaw Memory Plugin - mem0 + S3 Vectors
 * 
 * Delegates memory operations to a local mem0 Python service
 * which uses S3 Vectors for storage and Bedrock for LLM/embeddings.
 */

import { readFile, readdir, stat } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';

const PLUGIN_ID = 'memory-s3vectors';
const MEM0_BASE_URL = 'http://127.0.0.1:8765';
const DEFAULT_USER_ID = 'openclaw-main';

async function mem0Request(endpoint, body) {
  const resp = await fetch(`${MEM0_BASE_URL}${endpoint}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  if (!resp.ok) {
    const text = await resp.text();
    throw new Error(`mem0 ${endpoint} failed (${resp.status}): ${text}`);
  }
  return resp.json();
}

async function mem0Health() {
  try {
    const resp = await fetch(`${MEM0_BASE_URL}/health`, { signal: AbortSignal.timeout(3000) });
    return resp.ok;
  } catch {
    return false;
  }
}

function hashText(text) {
  return createHash('sha256').update(text).digest('hex').slice(0, 16);
}

async function listMemoryFiles(workspaceDir) {
  const files = [];
  const addFile = async (filePath) => {
    try {
      const stats = await stat(filePath);
      if (stats.isFile() && filePath.endsWith('.md')) files.push(filePath);
    } catch { /* skip */ }
  };

  await addFile(path.join(workspaceDir, 'MEMORY.md'));
  const memoryDir = path.join(workspaceDir, 'memory');
  if (existsSync(memoryDir)) {
    for (const entry of await readdir(memoryDir)) {
      if (entry.endsWith('.md')) await addFile(path.join(memoryDir, entry));
    }
  }
  return files;
}

class Mem0MemoryManager {
  constructor(config, workspaceDir) {
    this.config = config || {};
    this.workspaceDir = workspaceDir;
    this.userId = config?.userId || DEFAULT_USER_ID;
    this.fileHashes = new Map();
    this.fileCount = 0;
    this.chunkCount = 0;
    this.healthy = false;
  }

  async initialize() {
    this.healthy = await mem0Health();
    if (!this.healthy) {
      console.warn('[memory-s3vectors] mem0 service not available at', MEM0_BASE_URL);
    }
  }

  async sync() {
    if (!this.healthy) {
      this.healthy = await mem0Health();
      if (!this.healthy) return;
    }

    const files = await listMemoryFiles(this.workspaceDir);
    this.fileCount = files.length;

    for (const filePath of files) {
      await this.syncFile(filePath);
    }
  }

  async syncFile(filePath) {
    const content = await readFile(filePath, 'utf-8');
    const hash = hashText(content);
    const prevHash = this.fileHashes.get(filePath);

    if (prevHash === hash) return;

    const relPath = path.relative(this.workspaceDir, filePath);
    const chunks = this.chunkText(content, 800);
    
    for (const chunk of chunks) {
      if (chunk.trim().length < 20) continue;
      
      try {
        await mem0Request('/add', {
          messages: [
            { role: 'user', content: chunk },
            { role: 'assistant', content: `Memory recorded from ${relPath}` }
          ],
          user_id: this.userId,
          metadata: { source: relPath, synced_at: new Date().toISOString() }
        });
        this.chunkCount++;
      } catch (err) {
        console.error(`[memory-s3vectors] Error syncing chunk from ${relPath}:`, err.message);
      }
    }

    this.fileHashes.set(filePath, hash);
  }

  chunkText(text, maxChars = 800) {
    const lines = text.split('\n');
    const chunks = [];
    let current = [];
    let currentLen = 0;

    for (const line of lines) {
      if (currentLen + line.length > maxChars && current.length > 0) {
        chunks.push(current.join('\n'));
        current = [line];
        currentLen = line.length;
      } else {
        current.push(line);
        currentLen += line.length + 1;
      }
    }
    if (current.length > 0) chunks.push(current.join('\n'));
    return chunks;
  }

  async search(query, options = {}) {
    if (!this.healthy) {
      this.healthy = await mem0Health();
      if (!this.healthy) return [];
    }

    const { maxResults = 10 } = options;

    try {
      const data = await mem0Request('/search', {
        query,
        user_id: this.userId,
        limit: maxResults
      });

      return (data.results || []).map(r => ({
        path: 'mem0',
        startLine: 1,
        endLine: 1,
        score: r.score != null ? (1 - r.score) : 0.5,
        snippet: r.memory || '',
        source: 'memory'
      }));
    } catch (err) {
      console.error('[memory-s3vectors] Search error:', err.message);
      return [];
    }
  }

  async readFile(params) {
    const { relPath, from, lines } = params;
    const filePath = path.join(this.workspaceDir, relPath);
    
    if (!existsSync(filePath)) {
      return { text: '', path: filePath };
    }

    const content = await readFile(filePath, 'utf-8');
    const allLines = content.split('\n');
    
    const startIdx = Math.max(0, (from || 1) - 1);
    const endIdx = Math.min(allLines.length, lines ? startIdx + lines : allLines.length);
    
    return {
      text: allLines.slice(startIdx, endIdx).join('\n'),
      path: filePath
    };
  }

  status() {
    return {
      backend: 'mem0',
      provider: 'bedrock',
      model: 'amazon.titan-embed-text-v2:0',
      files: this.fileCount,
      chunks: this.chunkCount,
      custom: {
        service: MEM0_BASE_URL,
        healthy: this.healthy,
        userId: this.userId,
        vectorStore: 's3_vectors'
      }
    };
  }

  async close() {}
}

// Plugin registration
const managerCache = new Map();

async function getMemorySearchManager(params) {
  const { agentId = 'default', config } = params;
  const cacheKey = agentId;
  
  if (managerCache.has(cacheKey)) {
    return { manager: managerCache.get(cacheKey) };
  }

  try {
    const workspaceDir = config?.agents?.[agentId]?.workspace || process.cwd();
    const pluginConfig = config?.plugins?.entries?.['memory-s3vectors']?.config || {};
    const manager = new Mem0MemoryManager(pluginConfig, workspaceDir);
    await manager.initialize();
    managerCache.set(cacheKey, manager);
    return { manager };
  } catch (error) {
    return { manager: null, error: error.message };
  }
}

function definePluginEntry({ id, name, description, kind, configSchema = {}, register }) {
  return { id, name, description, ...kind ? { kind } : {}, configSchema, register };
}

const mem0MemoryPlugin = definePluginEntry({
  id: PLUGIN_ID,
  name: 'Memory (mem0 + S3 Vectors)',
  description: 'Intelligent memory layer using mem0 with S3 Vectors and Bedrock',
  kind: 'memory',
  configSchema: {
    type: 'object',
    additionalProperties: false,
    properties: {
      userId: { type: 'string' },
      serviceUrl: { type: 'string' }
    }
  },
  register(api) {
    api.registerMemoryRuntime({
      async getMemorySearchManager(params) {
        return await getMemorySearchManager(params);
      },
      resolveMemoryBackendConfig() {
        return { backend: 'builtin', custom: { provider: 'mem0-s3vectors' } };
      },
      async closeAllMemorySearchManagers() {
        for (const m of managerCache.values()) await m.close();
        managerCache.clear();
      }
    });
  }
});

export default mem0MemoryPlugin;
export { Mem0MemoryManager };
