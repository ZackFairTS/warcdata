# memory-s3vectors 完整实现指南

> ⚠️ **本文档描述 mem0 + S3 Vectors 插件的实现细节。完整恢复流程请看根目录 [README.md](../README.md)。**

本文档描述如何在新环境中从零搭建 mem0 + S3 Vectors 长期记忆系统，供 OpenClaw agent 使用。

## 架构概览

```
OpenClaw Agent
    ↓ (memory plugin, 自动同步 MEMORY.md)
memory-s3vectors 插件 (Node.js, OpenClaw 扩展)
    ↓ (HTTP API)
mem0 Python 服务 (FastAPI, port 8765)
    ↓
┌─────────────────────────┐
│  S3 Vectors (向量存储)    │  ← 每个 user_id 一个独立 index
│  Bedrock Titan v2 (嵌入) │
│  Bedrock Haiku (LLM)     │  ← mem0 用来提取/去重记忆
└─────────────────────────┘
```

**核心工作流：**
1. Agent workspace 里的 `MEMORY.md` 和 `memory/*.md` 文件变更时，插件自动读取并发送到 mem0
2. mem0 用 LLM 提取关键记忆，用 embedding 模型生成向量，存入 S3 Vectors
3. Agent 对话时，插件对用户消息做语义搜索，把相关记忆注入上下文
4. 每个 agent（user_id）有独立的向量索引，互不干扰

## 前置条件

### AWS 资源
- **AWS 账号**，配好 credentials（`~/.aws/credentials` 或 IAM Role）
- **Bedrock 模型访问权限**（在目标 region 开通）：
  - `amazon.titan-embed-text-v2:0`（embedding，1024 维）
  - Haiku 或其他 Claude 模型（mem0 内部用于记忆提取）
- **S3 Vectors**：需要创建一个 S3 Vectors bucket（注意：不是普通 S3 bucket）

### 创建 S3 Vectors Bucket

```bash
aws s3vectors create-vector-bucket \
  --vector-bucket-name openclaw-memory-vectors \
  --region ap-northeast-1
```

> S3 Vectors 目前仅在部分 region 可用（如 ap-northeast-1, us-east-1），请确认你的 region 支持。

### 软件
- Python 3.10+
- Node.js 20+
- OpenClaw 已安装

## 第一步：部署 mem0 Python 服务

### 1.1 创建目录和文件

```bash
mkdir -p ~/memory-s3vectors/mem0
cd ~/memory-s3vectors/mem0
```

### 1.2 创建 requirements.txt

```
mem0ai
boto3
fastapi
uvicorn
pydantic
pydantic-settings
```

### 1.3 安装依赖

```bash
pip install -r requirements.txt
# 或者如果提示 externally-managed:
pip install --break-system-packages -r requirements.txt
```

### 1.4 创建 service.py

这是核心服务文件。完整代码见附件 `service.py`（已包含在 mem0-export 中）。

关键配置项（通过环境变量或修改代码中的 Settings 类）：

| 配置项 | 默认值 | 说明 |
|---|---|---|
| `MEM0_AWS_REGION` | ap-northeast-1 | AWS Region |
| `MEM0_VECTOR_BUCKET_NAME` | openclaw-memory-vectors | S3 Vectors bucket 名称 |
| `MEM0_LLM_MODEL` | jp.anthropic.claude-haiku-4-5-20251001-v1:0 | LLM 模型 ID（需按 region 调整） |
| `MEM0_EMBEDDER_MODEL` | amazon.titan-embed-text-v2:0 | Embedding 模型 ID |

> **重要**：LLM 模型 ID 带有 region 前缀（如 `jp.`），换 region 时需要修改。

### 1.5 创建 start.sh

```bash
#!/bin/bash
cd ~/memory-s3vectors/mem0
export AWS_REGION=ap-northeast-1  # 改为你的 region
exec python3 -m uvicorn service:app --host 127.0.0.1 --port 8765 --log-level info
```

```bash
chmod +x start.sh
```

### 1.6 测试启动

```bash
./start.sh
# 另一个终端测试
curl http://127.0.0.1:8765/health
# 应返回 {"status":"healthy","service":"mem0","isolation":"per-user"}
```

### 1.7 创建 systemd 服务（开机自启）

```bash
mkdir -p ~/.config/systemd/user

cat > ~/.config/systemd/user/mem0-service.service << 'EOF'
[Unit]
Description=Mem0 Memory Service (S3 Vectors + Bedrock)
After=network.target

[Service]
Type=simple
ExecStart=/home/ubuntu/memory-s3vectors/mem0/start.sh
Restart=on-failure
RestartSec=5
Environment=AWS_REGION=ap-northeast-1

[Install]
WantedBy=default.target
EOF

systemctl --user daemon-reload
systemctl --user enable mem0-service
systemctl --user start mem0-service
systemctl --user status mem0-service
```

> 注意：ExecStart 路径需要改为实际路径。

## 第二步：安装 OpenClaw memory-s3vectors 插件

```bash
openclaw plugins install memory-s3vectors
```

安装后重启 gateway：

```bash
openclaw gateway restart
```

插件会自动连接 `http://127.0.0.1:8765` 的 mem0 服务。

### 验证插件加载

```bash
openclaw status
# 应该能看到 memory-s3vectors 插件已加载
```

## 第三步：恢复记忆数据

参见 `RESTORE-GUIDE.md` 中的恢复步骤。

## API 说明

mem0 服务提供以下 HTTP 端点（均为 POST）：

| 端点 | 用途 | 参数 |
|---|---|---|
| `GET /health` | 健康检查 | - |
| `GET /status` | 服务状态 | - |
| `POST /add` | 添加记忆 | messages, user_id, metadata |
| `POST /search` | 语义搜索 | query, user_id, limit |
| `POST /get_all` | 获取全部记忆 | user_id |
| `POST /delete` | 删除记忆 | memory_id, user_id |
| `POST /update` | 更新记忆 | memory_id, data, user_id |
| `POST /reset` | 重置用户记忆 | user_id |

### user_id 隔离

每个 `user_id` 对应 S3 Vectors 中一个独立的 index，命名规则：`mem0-{user_id}`。

例如：
- `cfo-assistant` → `mem0-cfo-assistant`
- `group-t` → `mem0-group-t`

OpenClaw 插件会自动为每个 agent 设置 user_id。

## 插件工作原理

memory-s3vectors 插件（`index.js`）的核心逻辑：

1. **文件同步**：监控 workspace 中的 `MEMORY.md` 和 `memory/*.md`，内容变化时自动发送到 mem0 的 `/add` 端点
2. **语义搜索**：agent 收到消息时，调 mem0 的 `/search` 端点获取相关记忆，注入对话上下文
3. **文件哈希**：用 SHA256 跟踪文件变化，避免重复同步
4. **容错**：mem0 服务不可用时静默降级，不影响 agent 正常工作

## 注意事项

1. **mem0 服务必须在 gateway 启动前运行**，否则插件初始化时会标记为不健康（但后续会自动重连）
2. **S3 Vectors ≠ 普通 S3**：不要用普通 S3 bucket，需要专门创建 S3 Vectors bucket
3. **Bedrock 模型 region**：确保 Titan Embed v2 和 LLM 模型在你选择的 region 可用
4. **内存占用**：mem0 Python 服务约 200MB 内存
5. **首次启动慢**：第一次为某个 user_id 添加记忆时，会创建 S3 Vectors index，可能需要几秒
