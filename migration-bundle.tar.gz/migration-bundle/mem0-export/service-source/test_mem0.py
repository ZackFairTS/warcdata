#!/usr/bin/env python3
"""
Test script for mem0 integration with S3 Vectors.
Run: python test_mem0.py
"""

import os
import sys
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def test_mem0_config():
    from mem0 import Memory
    
    os.environ["AWS_REGION"] = "ap-northeast-1"
    
    config = {
        "vector_store": {
            "provider": "s3vectors",
            "config": {
                "vector_bucket_name": "openclaw-memory-vectors",
                "collection_name": "mem0-memory-test",
                "embedding_model_dims": 1024,
                "distance_metric": "cosine",
                "region_name": "ap-northeast-1"
            }
        },
        "llm": {
            "provider": "aws_bedrock",
            "config": {
                "model": "anthropic.claude-haiku-4-5-20251001-v1:0",
                "temperature": 0.1
            }
        },
        "embedder": {
            "provider": "aws_bedrock",
            "config": {
                "model": "amazon.titan-embed-text-v2:0",
                "embedding_dims": 1024
            }
        }
    }
    
    logger.info("Creating mem0 Memory instance...")
    memory = Memory.from_config(config)
    logger.info("Mem0 Memory instance created successfully!")
    
    return memory


def test_add_memory(memory):
    logger.info("Testing add_memory...")
    
    messages = [
        {"role": "user", "content": "My name is John and I love Python programming."},
        {"role": "assistant", "content": "That's great! Python is a powerful language."},
        {"role": "user", "content": "I work at a startup in Tokyo."},
        {"role": "assistant", "content": "Tokyo is an amazing city!"}
    ]
    
    result = memory.add(messages, user_id="test_user")
    logger.info(f"Add result: {result}")
    
    return result


def test_search_memory(memory):
    logger.info("Testing search_memory...")
    
    results = memory.search("What is my name?", user_id="test_user", limit=3)
    logger.info(f"Search results: {results}")
    
    return results


def test_get_all_memory(memory):
    logger.info("Testing get_all_memory...")
    
    try:
        all_memories = memory.get_all(user_id="test_user")
    except AttributeError:
        all_memories = memory.get(user_id="test_user")
    
    logger.info(f"Found {len(all_memories) if all_memories else 0} memories")
    
    return all_memories


def test_delete_memory(memory, memory_id):
    logger.info(f"Testing delete_memory for id={memory_id}...")
    
    result = memory.delete(id=memory_id)
    logger.info(f"Delete result: {result}")
    
    return result


def test_update_memory(memory, memory_id):
    logger.info(f"Testing update_memory for id={memory_id}...")
    
    result = memory.update(id=memory_id, data="Updated: My name is John Doe.")
    logger.info(f"Update result: {result}")
    
    return result


def test_reset_memory(memory):
    logger.info("Testing reset_memory...")
    
    result = memory.reset(user_id="test_user")
    logger.info(f"Reset result: {result}")
    
    return result


def run_tests():
    logger.info("=" * 50)
    logger.info("Starting mem0 integration tests")
    logger.info("=" * 50)
    
    try:
        memory = test_mem0_config()
        
        test_add_memory(memory)
        
        search_results = test_search_memory(memory)
        
        if search_results and len(search_results) > 0:
            memory_id = search_results[0].get("id")
            
            if memory_id:
                test_update_memory(memory, memory_id)
                
                test_delete_memory(memory, memory_id)
        
        test_reset_memory(memory)
        
        logger.info("=" * 50)
        logger.info("All tests passed!")
        logger.info("=" * 50)
        
    except Exception as e:
        logger.error(f"Test failed: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    run_tests()
