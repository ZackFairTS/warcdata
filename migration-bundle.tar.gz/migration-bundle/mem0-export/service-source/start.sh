#!/bin/bash
cd /home/ubuntu/memory-s3vectors/mem0
export AWS_REGION=ap-northeast-1
exec python3 -m uvicorn service:app --host 127.0.0.1 --port 8765 --log-level info
