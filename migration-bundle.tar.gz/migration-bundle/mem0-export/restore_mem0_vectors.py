#!/usr/bin/env python3
"""
restore_mem0_vectors.py — Restore mem0 memories WITH vectors directly to S3 Vectors.

Writes vectors directly to S3 Vectors indexes without re-embedding or LLM calls.
Much faster, cheaper, and lossless compared to restore_mem0.py (which re-processes via mem0 /add).

Usage:
  python3 restore_mem0_vectors.py [--bucket openclaw-memory-vectors] [--region ap-northeast-1]
  python3 restore_mem0_vectors.py --dry-run
"""

import argparse
import glob
import json
import os
import sys

try:
    import boto3
except ImportError:
    print("需要 boto3: pip install boto3")
    sys.exit(1)


def ensure_index(client, bucket, index_name, config):
    """Create index if it doesn't exist."""
    try:
        client.get_index(vectorBucketName=bucket, indexName=index_name)
        return False  # already exists
    except client.exceptions.NotFoundException:
        client.create_index(
            vectorBucketName=bucket,
            indexName=index_name,
            dataType=config.get("dataType", "float32"),
            dimension=config.get("dimension", 1024),
            distanceMetric=config.get("distanceMetric", "cosine"),
        )
        return True  # created


def restore_file(client, bucket, filepath, dry_run=False):
    """Restore a single export file to S3 Vectors."""
    with open(filepath) as f:
        data = json.load(f)

    # Validate format
    if data.get("format") != "s3vectors-full":
        print(f"  ⚠️  {filepath}: unknown format '{data.get('format')}', skipping")
        return 0

    index_name = data["index_name"]
    config = data.get("index_config", {})
    vectors = data.get("vectors", [])

    print(f"\n{'='*50}")
    print(f"恢复 {index_name}: {len(vectors)} vectors")
    print(f"{'='*50}")

    if not vectors:
        print(f"  ⏭️  empty, skipping")
        return 0

    if dry_run:
        print(f"  [DRY RUN] Would create index {index_name} and write {len(vectors)} vectors")
        for v in vectors[:3]:
            meta = v.get("metadata", {})
            memory_text = meta.get("data", "")[:60] if isinstance(meta, dict) else ""
            print(f"  [DRY RUN]   - {memory_text}")
        if len(vectors) > 3:
            print(f"  [DRY RUN]   ... and {len(vectors)-3} more")
        return len(vectors)

    # Create index if needed
    created = ensure_index(client, bucket, index_name, config)
    if created:
        print(f"  ✅ 索引 {index_name} 已创建 (dims={config.get('dimension')}, metric={config.get('distanceMetric')})")
    else:
        print(f"  ℹ️  索引 {index_name} 已存在")

    # Batch put vectors (S3 Vectors supports up to 100 per call)
    batch_size = 50
    total_written = 0

    for i in range(0, len(vectors), batch_size):
        batch = vectors[i : i + batch_size]
        vectors_to_put = []

        for v in batch:
            entry = {
                "key": v["key"],
                "metadata": v.get("metadata", {}),
            }
            # Add vector data
            vector_data = v.get("vector")
            if vector_data:
                data_type = config.get("dataType", "float32")
                entry["data"] = {data_type: vector_data}

            vectors_to_put.append(entry)

        try:
            client.put_vectors(
                vectorBucketName=bucket,
                indexName=index_name,
                vectors=vectors_to_put,
            )
            total_written += len(batch)
            if len(vectors) > batch_size:
                print(f"  📝 {total_written}/{len(vectors)} vectors written...")
        except Exception as e:
            print(f"  ❌ Batch write error at offset {i}: {e}")

    print(f"  ✅ 写入完成: {total_written}/{len(vectors)} vectors")
    return total_written


def main():
    parser = argparse.ArgumentParser(description="Restore mem0 memories with vectors to S3 Vectors")
    parser.add_argument("--bucket", default="openclaw-memory-vectors", help="S3 Vectors bucket name")
    parser.add_argument("--region", default="ap-northeast-1", help="AWS region")
    parser.add_argument("--dry-run", action="store_true", help="Preview only, don't write")
    parser.add_argument("--files", default=None, help="Comma-separated export files (default: *-vectors.json)")
    args = parser.parse_args()

    client = boto3.client("s3vectors", region_name=args.region)

    # Find export files
    script_dir = os.path.dirname(os.path.abspath(__file__))
    if args.files:
        files = [os.path.join(script_dir, f.strip()) for f in args.files.split(",")]
    else:
        files = sorted(glob.glob(os.path.join(script_dir, "*-vectors.json")))

    if not files:
        print("❌ No *-vectors.json files found. Run export_mem0_vectors.py first.")
        sys.exit(1)

    print(f"S3 Vectors bucket: {args.bucket}")
    print(f"Region: {args.region}")
    print(f"Files: {len(files)}")

    total = 0
    for filepath in files:
        total += restore_file(client, args.bucket, filepath, args.dry_run)

    print(f"\n{'='*50}")
    if args.dry_run:
        print(f"Dry run 完成。共 {total} vectors 待恢复。")
    else:
        print(f"恢复完成！共写入 {total} vectors。")


if __name__ == "__main__":
    main()
