# Mem0 记忆恢复（仅 mem0 部分）

> ⚠️ **本文档仅覆盖 mem0 向量记忆的恢复。完整恢复流程（含 Athena、OpenSearch、Agent 部署等）请看根目录 [README.md](../README.md)。**

## 导出概览

### Mem0 向量记忆

| Agent / User ID | 记忆条数 | 导出文件 |
|---|---|---|
| cfo-assistant | 90 | `cfo-assistant-export.json` |
| data-analyst | 0 | `data-analyst-export.json` |
| compliance-auditor | 0 | `compliance-auditor-export.json` |
| group-t | 24 | `group-t-export.json` |

> `data-analyst` 和 `compliance-auditor` 的 mem0 向量记忆为空（它们的知识主要在 workspace 文件里）。

## 目录结构

```
mem0-export/
├── RESTORE-GUIDE.md                      # 本文档
├── restore_mem0.py                       # mem0 恢复脚本
├── cfo-assistant-export.json             # mem0 向量记忆导出
├── data-analyst-export.json
├── compliance-auditor-export.json
├── group-t-export.json
├── workspace-cfo-assistant/              # workspace 文件（MEMORY.md, SOUL.md 等）
├── workspace-data-analyst/
├── workspace-compliance-auditor/
├── agentdir-cfo-assistant/               # agent 配置（SOUL.md, models.json）
├── agentdir-data-analyst/
└── agentdir-compliance-auditor/
```

## 前置条件

新环境需要：
1. **OpenClaw** 已安装并运行
2. **mem0 服务** 已部署（基于 S3 Vectors + Bedrock）
3. **Python 3** + `requests` 库
4. mem0 服务监听在 `http://127.0.0.1:8765`（如不同请修改脚本中的 `MEM0_URL`）

### mem0 服务配置参考

```yaml
# 核心配置（来自原环境）
vector_store:
  provider: s3_vectors
  config:
    vector_bucket_name: "openclaw-memory-vectors"  # 改为新 bucket
    embedding_model_dims: 1024
    distance_metric: cosine
    region_name: ap-northeast-1  # 改为新 region

llm:
  provider: aws_bedrock
  config:
    model: "jp.anthropic.claude-haiku-4-5-20251001-v1:0"

embedder:
  provider: aws_bedrock
  config:
    model: "amazon.titan-embed-text-v2:0"
    embedding_dims: 1024
```

## 恢复步骤

### 第一步：恢复 workspace 文件

将各 agent 的 workspace 文件复制到新环境对应目录：

```bash
# 假设新环境的 workspace 路径
NEW_WS_CFO="/path/to/workspace-cfo"
NEW_WS_ANALYST="/path/to/workspace-analyst"
NEW_WS_AUDITOR="/path/to/workspace-auditor"

cp workspace-cfo-assistant/MEMORY.md "$NEW_WS_CFO/"
cp workspace-cfo-assistant/SOUL.md "$NEW_WS_CFO/"
cp workspace-cfo-assistant/AGENTS.md "$NEW_WS_CFO/"

cp workspace-data-analyst/MEMORY.md "$NEW_WS_ANALYST/"
cp workspace-data-analyst/SOUL.md "$NEW_WS_ANALYST/"
cp workspace-data-analyst/AGENTS.md "$NEW_WS_ANALYST/"

cp workspace-compliance-auditor/MEMORY.md "$NEW_WS_AUDITOR/"
cp workspace-compliance-auditor/SOUL.md "$NEW_WS_AUDITOR/"
cp workspace-compliance-auditor/AGENTS.md "$NEW_WS_AUDITOR/"
```

### 第二步：恢复 agent 配置

```bash
# 假设新环境的 agentDir 路径
NEW_AGENT_CFO="/path/to/.openclaw/agents/cfo-assistant/agent"
NEW_AGENT_ANALYST="/path/to/.openclaw/agents/data-analyst/agent"
NEW_AGENT_AUDITOR="/path/to/.openclaw/agents/compliance-auditor/agent"

cp agentdir-cfo-assistant/SOUL.md "$NEW_AGENT_CFO/"
cp agentdir-cfo-assistant/models.json "$NEW_AGENT_CFO/"
# models.json 可能需要根据新环境的模型配置调整

cp agentdir-data-analyst/SOUL.md "$NEW_AGENT_ANALYST/"
cp agentdir-data-analyst/models.json "$NEW_AGENT_ANALYST/"

cp agentdir-compliance-auditor/SOUL.md "$NEW_AGENT_AUDITOR/"
cp agentdir-compliance-auditor/models.json "$NEW_AGENT_AUDITOR/"
```

### 第三步：恢复 mem0 向量记忆

运行以下 Python 脚本将记忆写入新环境的 mem0 服务：

```python
#!/usr/bin/env python3
"""
restore_mem0.py — 将导出的 mem0 记忆恢复到新环境
用法: python3 restore_mem0.py [--dry-run] [--mem0-url http://127.0.0.1:8765]
"""

import json
import sys
import time
import argparse
import requests

EXPORT_FILES = [
    "cfo-assistant-export.json",
    "group-t-export.json",
    # data-analyst 和 compliance-auditor 为空，可跳过
]

def restore(mem0_url, dry_run=False):
    for filename in EXPORT_FILES:
        try:
            with open(filename) as f:
                data = json.load(f)
        except FileNotFoundError:
            print(f"⚠️  跳过 {filename}（文件不存在）")
            continue

        user_id = data["user_id"]
        memories = data["memories"]
        print(f"\n{'='*50}")
        print(f"恢复 {user_id}: {len(memories)} 条记忆")
        print(f"{'='*50}")

        for i, mem in enumerate(memories):
            memory_text = mem.get("memory", "")
            metadata = mem.get("metadata") or {}
            # 保留原始时间戳作为 metadata
            metadata["original_id"] = mem.get("id", "")
            metadata["original_created_at"] = mem.get("created_at", "")
            metadata["migrated"] = True

            if dry_run:
                print(f"  [{i+1}/{len(memories)}] [DRY RUN] {memory_text[:80]}...")
                continue

            try:
                resp = requests.post(
                    f"{mem0_url}/add",
                    json={
                        "messages": [
                            {"role": "user", "content": memory_text},
                            {"role": "assistant", "content": f"Restored memory for {user_id}"}
                        ],
                        "user_id": user_id,
                        "metadata": metadata,
                    },
                    timeout=30,
                )
                if resp.ok:
                    print(f"  [{i+1}/{len(memories)}] ✅ {memory_text[:60]}...")
                else:
                    print(f"  [{i+1}/{len(memories)}] ❌ {resp.status_code}: {resp.text[:100]}")
            except Exception as e:
                print(f"  [{i+1}/{len(memories)}] ❌ Error: {e}")

            # 避免请求过快
            time.sleep(0.5)

    print(f"\n{'='*50}")
    print("恢复完成！" if not dry_run else "Dry run 完成，未写入任何数据。")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--dry-run", action="store_true", help="仅预览，不实际写入")
    parser.add_argument("--mem0-url", default="http://127.0.0.1:8765", help="mem0 服务地址")
    args = parser.parse_args()
    restore(args.mem0_url, args.dry_run)
```

#### 使用方法

```bash
cd /path/to/mem0-export

# 先预览（不写入）
python3 restore_mem0.py --dry-run

# 确认无误后执行恢复
python3 restore_mem0.py

# 如果 mem0 服务在其他地址
python3 restore_mem0.py --mem0-url http://192.168.1.100:8765
```

### 第四步：验证

```bash
# 验证 cfo-assistant 的记忆
curl -s -X POST http://127.0.0.1:8765/get_all \
  -H "Content-Type: application/json" \
  -d '{"user_id": "cfo-assistant"}' | python3 -m json.tool | head -20

# 验证 group-t 的记忆
curl -s -X POST http://127.0.0.1:8765/search \
  -H "Content-Type: application/json" \
  -d '{"query": "预算超支", "user_id": "group-t", "limit": 5}' | python3 -m json.tool
```

## 注意事项

1. **向量会重新生成**：恢复时 mem0 会用新环境的 embedder 重新生成向量，所以不依赖原始向量数据
2. **mem0 去重**：mem0 内置去重逻辑，重复执行恢复脚本不会产生重复记忆
3. **user_id 必须一致**：新环境的 agent 配置中 user_id 需与导出时一致（`cfo-assistant`、`data-analyst`、`compliance-auditor`、`group-t`）
4. **S3 Vectors Bucket**：新环境需要自己的 S3 Vectors bucket，不要复用原环境的
5. **workspace 文件是独立记忆层**：MEMORY.md 等文件由 OpenClaw memory-s3vectors 插件自动索引同步，放到 workspace 后会自动被索引
6. **models.json 需适配**：agent 的 models.json 里的模型 ID 可能需要根据新环境的 Bedrock region 调整
