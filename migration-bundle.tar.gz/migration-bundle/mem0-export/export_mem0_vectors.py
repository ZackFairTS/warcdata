#!/usr/bin/env python3
"""
export_mem0_vectors.py — Export mem0 memories WITH vectors from S3 Vectors.

Exports full vector data + metadata so restore can write directly to S3 Vectors
without re-embedding or LLM calls.

Usage:
  python3 export_mem0_vectors.py [--bucket openclaw-memory-vectors] [--region ap-northeast-1]
  python3 export_mem0_vectors.py --indexes mem0-cfo-assistant,mem0-group-t
"""

import argparse
import json
import os
import sys
from datetime import datetime, timezone

try:
    import boto3
except ImportError:
    print("需要 boto3: pip install boto3")
    sys.exit(1)


def list_all_vectors(client, bucket, index_name):
    """Paginate through all vectors in an index, returning full data + metadata."""
    vectors = []
    kwargs = {
        "vectorBucketName": bucket,
        "indexName": index_name,
        "returnData": True,
        "returnMetadata": True,
        "maxResults": 100,
    }
    while True:
        resp = client.list_vectors(**kwargs)
        batch = resp.get("vectors", [])
        vectors.extend(batch)
        next_token = resp.get("nextToken")
        if not next_token or not batch:
            break
        kwargs["nextToken"] = next_token
    return vectors


def get_index_config(client, bucket, index_name):
    """Get index configuration (dims, metric, etc.)."""
    try:
        resp = client.get_index(vectorBucketName=bucket, indexName=index_name)
        return {
            "dataType": resp.get("dataType", "float32"),
            "dimension": resp.get("dimension", 1024),
            "distanceMetric": resp.get("distanceMetric", "cosine"),
        }
    except Exception:
        return {"dataType": "float32", "dimension": 1024, "distanceMetric": "cosine"}


def export_index(client, bucket, index_name, output_dir):
    """Export a single index to a JSON file."""
    print(f"\n{'='*50}")
    print(f"导出 {index_name}")
    print(f"{'='*50}")

    config = get_index_config(client, bucket, index_name)
    vectors = list_all_vectors(client, bucket, index_name)

    if not vectors:
        print(f"  ⏭️  {index_name}: 0 vectors, skipping")
        return None

    # Serialize vectors
    export_data = {
        "format": "s3vectors-full",
        "version": "1.0",
        "index_name": index_name,
        "source_bucket": bucket,
        "exported_at": datetime.now(timezone.utc).isoformat(),
        "index_config": config,
        "vector_count": len(vectors),
        "vectors": [],
    }

    for v in vectors:
        entry = {
            "key": v["key"],
            "metadata": v.get("metadata", {}),
        }
        # Include vector data
        data = v.get("data", {})
        if "float32" in data:
            entry["vector"] = data["float32"]
        elif "float64" in data:
            entry["vector"] = data["float64"]
        export_data["vectors"].append(entry)

    filename = f"{index_name}-vectors.json"
    filepath = os.path.join(output_dir, filename)
    with open(filepath, "w") as f:
        json.dump(export_data, f, ensure_ascii=False, default=str)

    size_mb = os.path.getsize(filepath) / (1024 * 1024)
    print(f"  ✅ {len(vectors)} vectors → {filename} ({size_mb:.1f} MB)")
    return filepath


def main():
    parser = argparse.ArgumentParser(description="Export mem0 memories with vectors from S3 Vectors")
    parser.add_argument("--bucket", default="openclaw-memory-vectors", help="S3 Vectors bucket name")
    parser.add_argument("--region", default="ap-northeast-1", help="AWS region")
    parser.add_argument("--indexes", default=None, help="Comma-separated index names (default: auto-detect)")
    parser.add_argument("--output-dir", default=".", help="Output directory")
    parser.add_argument("--skip-empty", action="store_true", default=True, help="Skip empty indexes")
    args = parser.parse_args()

    client = boto3.client("s3vectors", region_name=args.region)

    # Get index list
    if args.indexes:
        index_names = [i.strip() for i in args.indexes.split(",")]
    else:
        resp = client.list_indexes(vectorBucketName=args.bucket)
        index_names = [idx["indexName"] for idx in resp.get("indexes", [])]
        # Filter to mem0-* indexes (skip internal ones)
        index_names = [n for n in index_names if n.startswith("mem0-") and n not in ("mem0-default", "mem0-test", "mem0migrations")]

    print(f"S3 Vectors bucket: {args.bucket}")
    print(f"Region: {args.region}")
    print(f"Indexes to export: {index_names}")

    os.makedirs(args.output_dir, exist_ok=True)
    exported = []

    for name in index_names:
        result = export_index(client, args.bucket, name, args.output_dir)
        if result:
            exported.append(result)

    print(f"\n{'='*50}")
    print(f"导出完成！{len(exported)} 个索引已导出。")
    for f in exported:
        print(f"  📄 {f}")


if __name__ == "__main__":
    main()
