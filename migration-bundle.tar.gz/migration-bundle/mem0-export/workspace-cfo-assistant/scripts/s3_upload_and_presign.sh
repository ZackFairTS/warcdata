#!/usr/bin/env bash
#
# s3_upload_and_presign.sh — 上传文件到 S3 并生成 presigned URL
#
# 用法:
#   bash scripts/s3_upload_and_presign.sh <本地文件路径> [S3路径前缀]
#
# 示例:
#   bash scripts/s3_upload_and_presign.sh /tmp/q3_report.html reports/
#   bash scripts/s3_upload_and_presign.sh /tmp/chart.png charts/
#
# 功能:
#   1. 自动获取当前 AWS 账户 ID 和 region
#   2. 桶名格式: openclaw-reports-<account_id>-<YYYYMMDD 首次创建日>
#   3. 桶不存在则自动创建（带版本控制和加密）
#   4. 上传文件并生成 1 小时有效的 presigned URL
#   5. presigned URL 使用正确的区域端点签名
#
# 输出: 最后一行是 presigned URL，可直接 $(bash ...) 捕获
#

set -euo pipefail

# ── 参数 ──
LOCAL_FILE="${1:?用法: $0 <本地文件路径> [S3路径前缀]}"
S3_PREFIX="${2:-reports/}"

if [[ ! -f "$LOCAL_FILE" ]]; then
  echo "❌ 文件不存在: $LOCAL_FILE" >&2
  exit 1
fi

# ── 获取 AWS 账户 ID ──
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text 2>/dev/null)
if [[ -z "$ACCOUNT_ID" ]]; then
  echo "❌ 无法获取 AWS 账户 ID，请检查凭证配置" >&2
  exit 1
fi

# ── 获取当前 region ──
get_region() {
  # 1. 环境变量
  if [[ -n "${AWS_REGION:-}" ]]; then echo "$AWS_REGION"; return; fi
  if [[ -n "${AWS_DEFAULT_REGION:-}" ]]; then echo "$AWS_DEFAULT_REGION"; return; fi

  # 2. AWS CLI 配置
  local cli_region
  cli_region=$(aws configure get region 2>/dev/null || true)
  if [[ -n "$cli_region" ]]; then echo "$cli_region"; return; fi

  # 3. EC2 IMDSv2
  local token imds_region
  token=$(curl -s -m 2 -X PUT "http://169.254.169.254/latest/api/token" \
    -H "X-aws-ec2-metadata-token-ttl-seconds: 21600" 2>/dev/null || true)
  if [[ -n "$token" ]]; then
    imds_region=$(curl -s -m 2 -H "X-aws-ec2-metadata-token: $token" \
      "http://169.254.169.254/latest/meta-data/placement/region" 2>/dev/null || true)
    if [[ -n "$imds_region" ]]; then echo "$imds_region"; return; fi
  fi

  # 4. 兜底
  echo "ap-northeast-1"
}

REGION=$(get_region)
ENDPOINT="https://s3.${REGION}.amazonaws.com"

echo "📍 账户: ${ACCOUNT_ID} | 区域: ${REGION}" >&2

# ── 确定桶名（查找已有的或创建新的）──
find_or_create_bucket() {
  # 查找当前账户下是否已有 openclaw-reports-<account_id>-* 的桶
  local existing
  existing=$(aws s3api list-buckets --query "Buckets[?starts_with(Name, 'openclaw-reports-${ACCOUNT_ID}-')].Name" \
    --output text 2>/dev/null | head -1)

  if [[ -n "$existing" && "$existing" != "None" ]]; then
    echo "$existing"
    return
  fi

  # 也检查旧格式的桶 openclaw-analytics-<account_id>
  existing=$(aws s3api list-buckets --query "Buckets[?starts_with(Name, 'openclaw-analytics-${ACCOUNT_ID}')].Name" \
    --output text 2>/dev/null | head -1)

  if [[ -n "$existing" && "$existing" != "None" ]]; then
    echo "$existing"
    return
  fi

  # 创建新桶
  local today
  today=$(date -u +%Y%m%d)
  local bucket_name="openclaw-reports-${ACCOUNT_ID}-${today}"

  echo "🪣 创建新桶: ${bucket_name}" >&2

  if [[ "$REGION" == "us-east-1" ]]; then
    aws s3api create-bucket --bucket "$bucket_name" --region "$REGION" >/dev/null
  else
    aws s3api create-bucket --bucket "$bucket_name" --region "$REGION" \
      --create-bucket-configuration LocationConstraint="$REGION" >/dev/null
  fi

  # 开启默认加密
  aws s3api put-bucket-encryption --bucket "$bucket_name" \
    --server-side-encryption-configuration '{
      "Rules": [{"ApplyServerSideEncryptionByDefault": {"SSEAlgorithm": "AES256"}}]
    }' 2>/dev/null || true

  # 开启版本控制
  aws s3api put-bucket-versioning --bucket "$bucket_name" \
    --versioning-configuration Status=Enabled 2>/dev/null || true

  echo "$bucket_name"
}

BUCKET=$(find_or_create_bucket)
echo "🪣 使用桶: ${BUCKET}" >&2

# ── 上传文件 ──
FILENAME=$(basename "$LOCAL_FILE")
S3_KEY="${S3_PREFIX%/}/${FILENAME}"

# 根据扩展名设置 Content-Type
CONTENT_TYPE="application/octet-stream"
case "${FILENAME,,}" in
  *.html) CONTENT_TYPE="text/html; charset=utf-8" ;;
  *.png)  CONTENT_TYPE="image/png" ;;
  *.jpg|*.jpeg) CONTENT_TYPE="image/jpeg" ;;
  *.pdf)  CONTENT_TYPE="application/pdf" ;;
  *.json) CONTENT_TYPE="application/json" ;;
  *.csv)  CONTENT_TYPE="text/csv" ;;
esac

echo "📤 上传: ${LOCAL_FILE} → s3://${BUCKET}/${S3_KEY}" >&2
aws s3 cp "$LOCAL_FILE" "s3://${BUCKET}/${S3_KEY}" \
  --region "$REGION" \
  --content-type "$CONTENT_TYPE" \
  --quiet

# ── 生成 presigned URL（1小时有效）──
PRESIGNED_URL=$(aws s3 presign "s3://${BUCKET}/${S3_KEY}" \
  --region "$REGION" \
  --expires-in 3600 \
  --endpoint-url "$ENDPOINT")

echo "✅ 上传完成，presigned URL（1小时有效）:" >&2
echo "$PRESIGNED_URL"
