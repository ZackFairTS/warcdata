# Migration Bundle Guide

> **Updated**: 2026-04-16
> **Source**: Ubuntu server running OpenClaw 2026.3.28 (ap-northeast-1)
> **Scope**: 3-agent budget analysis team + mem0 memory + OpenSearch knowledge base + Athena data

---

## Quick Start (One Command)

```bash
tar xzf migration-bundle.tar.gz
cd migration-bundle
bash scripts/restore_all.sh --region ap-northeast-1
```

This runs all steps automatically. After completion, restart the gateway:
```bash
openclaw gateway restart
openclaw status
```

To skip specific components:
```bash
bash scripts/restore_all.sh --skip-athena --skip-opensearch  # Only deploy agents + mem0
bash scripts/restore_all.sh --skip-mem0                       # Skip mem0 service + memories
```

---

## Individual Scripts

If you prefer to run steps manually, each script can be executed independently:

| Script | What it does |
|--------|-------------|
| `athena-export/setup_athena.sh` | Creates S3 bucket, uploads parquet data, creates Glue DB/tables/views |
| `scripts/setup_mem0.sh` | Deploys mem0 service files, creates systemd unit, starts service |
| `scripts/deploy_agents.sh` | Deploys agent dirs, workspaces, models.json, npm deps, shared scripts |
| `scripts/merge_config.sh` | Merges 3 agents into openclaw.json (idempotent, uses default model) |
| `scripts/setup_s3_signer.sh` | Creates IAM user for clean presigned URLs, saves credentials |
| `mem0-export/restore_mem0.py` | Restores mem0 memories (89 cfo-assistant + 24 group-t) |
| `opensearch-export/restore_opensearch.py` | Restores OpenSearch budget-knowledge index (43 docs) |

Recommended order if running manually:
```bash
# Phase 1: Data layer
bash athena-export/setup_athena.sh --region ap-northeast-1
sudo systemctl start opensearch && python3 opensearch-export/restore_opensearch.py
bash scripts/setup_mem0.sh && cd mem0-export && python3 restore_mem0.py && cd ..

# Phase 2: Agents
bash scripts/deploy_agents.sh

# Phase 3: Config
bash scripts/merge_config.sh
bash scripts/setup_s3_signer.sh

# Apply
openclaw gateway restart
```

---

## Bundle Contents

```
migration-bundle/
├── MIGRATION-GUIDE.md               # This file
├── openclaw.json.reference          # Source machine's config (reference only)
│
├── scripts/                         # Migration automation scripts
│   ├── restore_all.sh               # One-shot full restore (main entry point)
│   ├── deploy_agents.sh             # Deploy agent dirs, workspaces, deps
│   ├── merge_config.sh              # Merge agents into openclaw.json
│   ├── setup_mem0.sh                # Deploy + start mem0 service
│   └── setup_s3_signer.sh           # Create IAM user for presigned URLs
│
├── athena-export/                   # Athena database + data
│   ├── setup_athena.sh              # Init script (bucket, tables, views)
│   ├── README.md
│   └── data/*.parquet               # 4 budget data files
│
├── mem0-export/
│   ├── workspace-cfo-assistant/     # 周总助 workspace
│   ├── workspace-data-analyst/      # 老陈 workspace
│   ├── workspace-compliance-auditor/# 赵合规 workspace
│   ├── agentdir-*/                  # Agent personality files (SOUL.md)
│   ├── *-export.json                # mem0 memory dumps
│   ├── service-source/              # mem0 service source code
│   ├── plugin-source/               # OpenClaw memory-s3vectors plugin
│   └── restore_mem0.py              # Memory restore script
│
└── opensearch-export/
    ├── opensearch-budget-knowledge.json  # Index dump (43 chunks)
    ├── skill-source/                     # OpenSearch skill source
    └── restore_opensearch.py             # Index restore script
```

## Key Files Per Agent

### 周总助 (cfo-assistant) — Coordinator
- `MEMORY.md` — Work rules, lessons learned, team coordination patterns
- `scripts/s3_upload_and_presign.sh` — HTML report upload + presigned URL
- `scripts/.s3_signer_creds` — IAM static credentials (created by setup_s3_signer.sh)
- `skills/budget-control/` — Budget control skill

### 老陈 (data-analyst) — Data Analysis
- `MEMORY.md` — Athena queries, ECharts workflow, tech experience
- `scripts/echart_render.js` — Server-side ECharts rendering
- `scripts/athena_query.py` — Athena SQL query helper
- `skills/athena-query/` — AWS Athena query skill
- `skills/opensearch-knowledge/` — OpenSearch search skill
- `skills/mem0-memory/` — mem0 memory skill

### 赵合规 (compliance-auditor) — Compliance
- `MEMORY.md` — Policy knowledge, OpenSearch usage
- `skills/compliance-search/` — Compliance search skill
- `Q3_Compliance_Review.md` — Q3 review document

---

## Post-Migration Checklist

- [ ] `openclaw status` shows all 3 agents
- [ ] Each agent responds without "No API key" errors
- [ ] CFO assistant can spawn/dispatch to data-analyst and compliance-auditor
- [ ] Athena: `python3 ~/budget-demo/scripts/athena_query.py "SELECT * FROM budget_summary LIMIT 3"`
- [ ] OpenSearch: `curl localhost:9200/budget-knowledge/_count`
- [ ] mem0: `curl localhost:8765/health`

## Environment-Specific Updates

If deploying to a **different region or AWS account**, update after migration:
- `~/budget-demo/workspace-analyst/skills/athena-query/SKILL.md` — S3 bucket name, output path, region
- `~/budget-demo/scripts/athena_query.py` — `REGION` variable

---

## Notes
- Feishu (飞书) integrations have been removed. Report output is HTML + S3 presigned URL.
- `models.json` is auto-generated per-machine; `deploy_agents.sh` copies it from the main agent.
- The S3 signer IAM user has minimal permissions (s3:GetObject only).
- All scripts are idempotent — safe to re-run.
