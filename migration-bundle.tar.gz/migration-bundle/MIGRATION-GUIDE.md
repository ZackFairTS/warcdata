# Migration Bundle Guide

> **Updated**: 2026-04-16
> **Source**: Ubuntu server running OpenClaw 2026.3.28 (ap-northeast-1)
> **Scope**: 3-agent budget analysis team + mem0 memory + OpenSearch knowledge base + Athena data

---

## Prerequisites

- **OS**: Linux (Ubuntu 22.04+ recommended)
- **Python**: 3.10+
- **AWS credentials**: IAM role or access keys with permissions for S3, Athena, Glue, Bedrock, S3 Vectors, IAM
- **Auto-installed**: The restore script automatically installs missing tools:
  - AWS CLI v2
  - `unzip`
  - Docker (for OpenSearch)
  - Python packages (`boto3 ≥1.38` for S3 Vectors support, `pydantic-settings`, etc.)

## Cross-Region Deployment

The migration bundle was created in `ap-northeast-1`, but can deploy to any AWS region.

**Automatic handling:**
- **Region detection**: If `--region` is not specified, the script auto-detects from EC2 IMDS → `aws configure` → environment variables
- **mem0 LLM model**: Automatically mapped to the correct Bedrock cross-region inference profile:
  - `ap-northeast-1` → `jp.anthropic.claude-haiku-4-5-20251001-v1:0`
  - `us-east-1` / `us-west-2` → `us.anthropic.claude-3-haiku-20240307-v1:0`
  - `eu-west-1` / `eu-central-1` → `eu.anthropic.claude-3-haiku-20240307-v1:0`
- **S3 bucket names**: Account-specific (auto-created with account ID suffix)
- **Athena SKILL.md**: Bucket references updated post-deploy

**Verified regions**: `ap-northeast-1`, `us-east-1`

---

## Quick Start (One Command)

```bash
tar xzf migration-bundle.tar.gz
cd migration-bundle
bash scripts/restore_all.sh --region ap-northeast-1
```

This runs all steps automatically. After completion, restart the gateway:
```bash
openclaw gateway restart
openclaw status
```

To skip specific components:
```bash
bash scripts/restore_all.sh --skip-athena --skip-opensearch  # Only deploy agents + mem0
bash scripts/restore_all.sh --skip-mem0                       # Skip mem0 service + memories
```

---

## Individual Scripts

If you prefer to run steps manually, each script can be executed independently:

| Script | What it does |
|--------|-------------|
| `athena-export/setup_athena.sh` | Creates S3 bucket, uploads parquet data, creates Glue DB/tables/views |
| `scripts/setup_mem0.sh` | Deploys mem0 service files, creates systemd unit, starts service |
| `scripts/deploy_agents.sh` | Deploys agent dirs, workspaces, models.json, npm deps, shared scripts |
| `scripts/merge_config.sh` | Merges 3 agents into openclaw.json (idempotent, uses default model) |
| `scripts/setup_opensearch.sh` | Ensures OpenSearch is running (auto-installs Docker if needed) |
| `scripts/setup_s3_signer.sh` | Creates IAM user for clean presigned URLs, saves credentials |
| `mem0-export/restore_mem0.py` | Restores mem0 memories via /add API (re-embeds, slower fallback) |
| `mem0-export/restore_mem0_vectors.py` | Restores mem0 vectors directly to S3 Vectors (fast, lossless) |
| `mem0-export/export_mem0_vectors.py` | Exports mem0 memories WITH vectors from S3 Vectors |
| `opensearch-export/restore_opensearch.py` | Restores OpenSearch budget-knowledge index (43 docs) |

Recommended order if running manually:
```bash
# Phase 1: Data layer
bash athena-export/setup_athena.sh --region ap-northeast-1
bash scripts/setup_opensearch.sh && python3 opensearch-export/restore_opensearch.py
bash scripts/setup_mem0.sh && cd mem0-export && python3 restore_mem0.py && cd ..

# Phase 2: Agents
bash scripts/deploy_agents.sh

# Phase 3: Config
bash scripts/merge_config.sh
bash scripts/setup_s3_signer.sh

# Apply
openclaw gateway restart
```

---

## Bundle Contents

```
migration-bundle/
├── MIGRATION-GUIDE.md               # This file
├── openclaw.json.reference          # Source machine's config (reference only)
│
├── scripts/                         # Migration automation scripts
│   ├── restore_all.sh               # One-shot full restore (main entry point)
│   ├── deploy_agents.sh             # Deploy agent dirs, workspaces, deps
│   ├── merge_config.sh              # Merge agents into openclaw.json
│   ├── setup_opensearch.sh          # Ensure OpenSearch running (Docker auto-install)
│   ├── setup_mem0.sh                # Deploy + start mem0 service
│   └── setup_s3_signer.sh           # Create IAM user for presigned URLs
│
├── athena-export/                   # Athena database + data
│   ├── setup_athena.sh              # Init script (bucket, tables, views)
│   ├── README.md
│   └── data/*.parquet               # 4 budget data files
│
├── mem0-export/
│   ├── workspace-cfo-assistant/     # 周总助 workspace
│   ├── workspace-data-analyst/      # 老陈 workspace
│   ├── workspace-compliance-auditor/# 赵合规 workspace
│   ├── agentdir-*/                  # Agent personality files (SOUL.md)
│   ├── *-export.json                # mem0 memory dumps (text only, fallback)
│   ├── *-vectors.json               # mem0 vector exports (full vectors + metadata)
│   ├── export_mem0_vectors.py       # Vector export script
│   ├── restore_mem0_vectors.py      # Vector restore script (preferred)
│   ├── service-source/              # mem0 service source code
│   ├── plugin-source/               # OpenClaw memory-s3vectors plugin
│   └── restore_mem0.py              # Memory restore script (text-only fallback)
│
└── opensearch-export/
    ├── opensearch-budget-knowledge.json  # Index dump (43 chunks)
    ├── skill-source/                     # OpenSearch skill source
    └── restore_opensearch.py             # Index restore script
```

## Key Files Per Agent

### 周总助 (cfo-assistant) — Coordinator
- `MEMORY.md` — Work rules, lessons learned, team coordination patterns
- `scripts/s3_upload_and_presign.sh` — HTML report upload + presigned URL
- `scripts/.s3_signer_creds` — IAM static credentials (created by setup_s3_signer.sh)
- `skills/budget-control/` — Budget control skill

### 老陈 (data-analyst) — Data Analysis
- `MEMORY.md` — Athena queries, ECharts workflow, tech experience
- `scripts/echart_render.js` — Server-side ECharts rendering
- `scripts/athena_query.py` — Athena SQL query helper
- `skills/athena-query/` — AWS Athena query skill
- `skills/opensearch-knowledge/` — OpenSearch search skill
- `skills/mem0-memory/` — mem0 memory skill

### 赵合规 (compliance-auditor) — Compliance
- `MEMORY.md` — Policy knowledge, OpenSearch usage
- `skills/compliance-search/` — Compliance search skill
- `Q3_Compliance_Review.md` — Q3 review document

---

## Post-Migration Checklist

- [ ] `openclaw status` shows all 3 agents
- [ ] Each agent responds without "No API key" errors
- [ ] CFO assistant can spawn/dispatch to data-analyst and compliance-auditor
- [ ] Main agent can `sessions_send` to cfo-assistant (`tools.sessions.visibility=all` + `main` in `agentToAgent.allow`)
- [ ] Athena: `python3 ~/budget-demo/scripts/athena_query.py "SELECT * FROM budget_summary LIMIT 3"`
- [ ] OpenSearch: `curl localhost:9200/budget-knowledge/_count`
- [ ] mem0: `curl localhost:8765/health`

### Cross-Agent Communication

迁移脚本 (`merge_config.sh`) 已自动配置以下两项，支持跨 agent 通信：

- `tools.sessions.visibility: "all"` — 跨 agent session 可见
- `tools.agentToAgent.allow: ["main", "cfo-assistant", "data-analyst", "compliance-auditor"]` — 所有 agent 互相可通信

**但以下内容需要根据你的使用方式手动配置：**

#### 方式一：sessions_send（平级通信，推荐用于 main → cfo-assistant）

`sessions_send` 通过 `sessionKey` 定位目标 agent 的 session，格式为 `agent:<agentId>:<sessionName>`。

**调用示例（已验证可用）：**

```
sessions_send(
  sessionKey: "agent:cfo-assistant:main",
  message: "帮我分析一下 Q3 预算执行情况",
  timeoutSeconds: 60
)
```

**要求：**
- `tools.sessions.visibility: "all"` ✅ 已配置
- `tools.agentToAgent.allow` 包含发送方和接收方 ✅ 已配置
- **不需要** `subagents.allowAgents`

**特点：**
- 同步调用，等待目标 agent 回复（最多 timeoutSeconds 秒）
- session 持久，可多次对话（同一个 sessionKey 保持上下文）
- 目标 agent 是独立的，不是调用方的子 agent

**sessionKey 命名规则：**

格式为 `agent:<agentId>:main`，这是确定性的命名规则，**不需要预先存在**。首次发送时 Gateway 会自动创建 session。

| 目标 Agent | sessionKey |
|-----------|-----------|
| cfo-assistant（周总助） | `agent:cfo-assistant:main` |
| data-analyst（老陈） | `agent:data-analyst:main` |
| compliance-auditor（赵合规） | `agent:compliance-auditor:main` |

> 💡 新机器恢复后没有任何已存在的 session，直接用上述 sessionKey 发消息即可，Gateway 会自动创建目标 agent 的 session。

**错误排查：**
- `agentId` 参数不能用于定位 agent，必须用 `sessionKey`
- `label` 参数要求 session 已存在，首次调用用 `sessionKey` 更可靠
- 如果报 `forbidden: Session send visibility is restricted` → 检查 `tools.sessions.visibility`
- 如果报 `Agent-to-agent messaging denied` → 检查 `tools.agentToAgent.allow` 是否包含发送方

#### 方式二：sessions_spawn（父子关系，推荐用于 cfo-assistant → 老陈/赵合规）

`sessions_spawn` 创建子 agent session，调用方是 parent。

**调用示例：**

```
sessions_spawn(
  agentId: "data-analyst",
  mode: "run",
  task: "查询 Q3 各部门预算执行率",
  runTimeoutSeconds: 120
)
```

**要求：**
- 调用方必须配置 `subagents.allowAgents` 包含目标 agent

**当前配置：**

| 调用方 | subagents.allowAgents | 可 spawn 的目标 |
|--------|----------------------|----------------|
| main | `["data-analyst", "compliance-auditor"]` | 老陈、赵合规 |
| cfo-assistant | `["data-analyst", "compliance-auditor"]` | 老陈、赵合规 |

> 注意：main 不将 cfo-assistant 作为子 agent spawn，而是通过 sessions_send 平级通信。

**特点：**
- 异步调用，完成后通过 auto-announce 推送结果
- 一次性（mode=run）或持久（mode=session）
- 子 session 的 key 格式：`agent:<agentId>:subagent:<uuid>`

#### 完整通信矩阵

| 调用方 | → 目标 | 方式 | 配置依赖 |
|--------|--------|------|---------|
| main → cfo-assistant | `sessions_send` (平级) | agentToAgent + sessions.visibility |
| main → data-analyst | `sessions_send` 或 `sessions_spawn` | agentToAgent 或 subagents |
| main → compliance-auditor | `sessions_send` 或 `sessions_spawn` | agentToAgent 或 subagents |
| cfo-assistant → data-analyst | `sessions_spawn` (子 agent) | subagents.allowAgents |
| cfo-assistant → compliance-auditor | `sessions_spawn` (子 agent) | subagents.allowAgents |

> ⚠️ 修改 `openclaw.json` 后，需重启 Gateway 生效：`openclaw gateway restart`

---

### Device Permissions for Sub-Agent Dispatch

The CFO assistant (cfo-assistant) spawns sub-agents (data-analyst, compliance-auditor) via the Gateway. This requires the connecting client device to have **`operator.admin`** scope. By default, webchat / Control UI devices may only have `operator.read`.

**Symptom:** CFO agent fails to dispatch tasks to sub-agents with a permission error mentioning `operator.admin` required.

**Fix:** Upgrade the device's operator scope:

```bash
# 1. Find the device ID
openclaw devices list

# 2. Rotate with admin scope
openclaw devices rotate --device <deviceId> --role operator --scope operator.admin

# 3. Reconnect the webchat / Control UI (refresh browser)
```

Alternatively, if the device was just paired and still pending:
```bash
# Approve with admin scope directly
openclaw devices approve --latest
```

> **Note:** `operator.admin` is a superset that includes read/write. Only grant it to trusted clients (e.g. your own browser, not shared links).

## Environment-Specific Updates

If deploying to a **different region or AWS account**, update after migration:
- `~/budget-demo/workspace-analyst/skills/athena-query/SKILL.md` — S3 bucket name, output path, region
- `~/budget-demo/scripts/athena_query.py` — `REGION` variable

---

## Notes
- Feishu (飞书) integrations have been removed. Report output is HTML + S3 presigned URL.
- `models.json` is auto-generated per-machine; `deploy_agents.sh` copies it from the main agent.
- The S3 signer IAM user has minimal permissions (s3:GetObject only).
- All scripts are idempotent — safe to re-run.
- OpenSearch auto-setup: checks systemd service first, then falls back to Docker. If Docker is not installed, `docker.io` is installed via apt automatically. Container runs with `--restart unless-stopped` and persists `vm.max_map_count` in `/etc/sysctl.conf`.
