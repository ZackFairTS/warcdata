# OpenSearch Configuration Reference

## Index Settings

### Basic Configuration

```json
{
  "settings": {
    "index": {
      "knn": true,
      "knn.space_type": "cosinesimil",
      "number_of_shards": 1,
      "number_of_replicas": 0
    }
  }
}
```

### CJK Analyzer Configuration

For Chinese text search support:

```json
{
  "analysis": {
    "analyzer": {
      "cjk_analyzer": {
        "type": "standard",
        "stopwords": "_cjk_stops_"
      }
    }
  }
}
```

## Index Mappings

### Dense Vector Field (k-NN)

```json
{
  "embedding": {
    "type": "knn_vector",
    "dimension": 1024,
    "method": {
      "engine": "nmslib",
      "space_type": "cosinesimil",
      "function": "l2"
    }
  }
}
```

Supported engines: `nmslib`, `faiss`, `lucene`

### Text Fields with Multiple Analyzers

```json
{
  "content": {
    "type": "text",
    "analyzer": "standard",
    "fields": {
      "cjk": {
        "type": "text",
        "analyzer": "cjk_analyzer"
      }
    }
  }
}
```

### Keyword Fields

```json
{
  "filename": { "type": "keyword" },
  "file_type": { "type": "keyword" },
  "tags": { "type": "keyword" }
}
```

## Hybrid Search Queries

### Using hybrid Query (OpenSearch 2.9+)

```json
{
  "query": {
    "hybrid": {
      "queries": [
        { "match": { "content": "查询文本" } },
        {
          "knn": {
            "embedding": {
              "vector": [0.1, 0.2, ...],
              "k": 10
            }
          }
        }
      ]
    }
  }
}
```

### Using bool Query with should

```json
{
  "query": {
    "bool": {
      "should": [
        { "match": { "content": "查询文本" } },
        {
          "knn": {
            "embedding": {
              "vector": [0.1, 0.2, ...],
              "k": 10
            }
          }
        }
      ]
    }
  }
}
```

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| OPENSEARCH_URL | http://localhost:9200 | OpenSearch endpoint |
| OPENSEARCH_USERNAME | admin | Auth username |
| OPENSEARCH_PASSWORD | admin | Auth password |
| INDEX_NAME | openclaw-knowledge | Index name |
| AWS_REGION | ap-northeast-1 | AWS region for Bedrock |

## Bedrock Titan Embed v2

### Model Configuration
- Model ID: `amazon.titan-embed-text-v2:0`
- Dimension: 1024
- Region: ap-northeast-1 (default)

### Request Format
```json
{
  "inputText": "文本内容"
}
```

### Response Format
```json
{
  "embedding": [0.1, 0.2, ...]
}
```

## Common Issues

### k-NN Not Enabled
Error: `"index.knn setting must be enabled"`
Fix: Add `"index.knn": true` to settings

### Dimension Mismatch
Error: `"dimension mismatch"`
Fix: Ensure embedding dimension matches index mapping

### Node Not Connected to Cluster
Error: `"No nodes connected"`
Fix: Check OpenSearch is running and accessible

## Performance Tips

1. Use bulk indexing for large documents
2. Set appropriate `number_of_shards` based on data size
3. Use `search_after` for deep pagination
4. Enable index refresh only when needed
5. Consider data tiering for large datasets