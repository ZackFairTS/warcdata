#!/usr/bin/env python3
"""
restore_opensearch.py — 将导出的 OpenSearch 知识库恢复到新环境
用法: python3 restore_opensearch.py [--dry-run] [--url http://localhost:9200]
"""

import json
import sys
import os
import argparse

try:
    from opensearchpy import OpenSearch
    from opensearchpy.helpers import bulk
except ImportError:
    print("需要 opensearch-py 库: pip install opensearch-py")
    sys.exit(1)

EXPORT_FILES = [
    "opensearch-budget-knowledge.json",
]


def restore(opensearch_url, dry_run=False):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    client = OpenSearch(hosts=[opensearch_url], use_ssl=False, verify_certs=False)

    for filename in EXPORT_FILES:
        filepath = os.path.join(script_dir, filename)
        try:
            with open(filepath) as f:
                data = json.load(f)
        except FileNotFoundError:
            print(f"⚠️  跳过 {filename}（文件不存在）")
            continue

        index_name = data["index_name"]
        docs = data["documents"]
        settings = data.get("settings", {})
        mappings = data.get("mappings", {})

        print(f"\n{'='*50}")
        print(f"恢复索引: {index_name} ({len(docs)} 文档)")
        print(f"{'='*50}")

        if dry_run:
            print(f"  [DRY RUN] 将创建索引 {index_name}")
            print(f"  [DRY RUN] 将写入 {len(docs)} 文档")
            for doc in docs[:3]:
                src = doc["_source"]
                preview = src.get("title") or src.get("filename") or str(src.get("content", ""))[:60]
                print(f"  [DRY RUN]   - {preview}")
            if len(docs) > 3:
                print(f"  [DRY RUN]   ... 还有 {len(docs)-3} 文档")
            continue

        # Create index if not exists
        if not client.indices.exists(index=index_name):
            # Extract clean settings (remove read-only fields)
            index_settings = settings.get("index", {})
            clean_settings = {}
            for k in ["knn", "knn.space_type", "number_of_shards", "number_of_replicas"]:
                if k in index_settings:
                    clean_settings[k] = index_settings[k]
            # Preserve analysis settings
            if "analysis" in index_settings:
                clean_settings["analysis"] = index_settings["analysis"]

            body = {
                "settings": {"index": clean_settings},
                "mappings": mappings,
            }
            client.indices.create(index=index_name, body=body)
            print(f"  ✅ 索引 {index_name} 已创建")
        else:
            print(f"  ⚠️  索引 {index_name} 已存在，将追加文档")

        # Bulk index documents
        def gen_actions():
            for doc in docs:
                yield {
                    "_index": index_name,
                    "_id": doc["_id"],
                    "_source": doc["_source"],
                }

        success, failed = bulk(client, gen_actions())
        print(f"  ✅ 写入完成: 成功 {success}, 失败 {len(failed) if isinstance(failed, list) else failed}")

    print(f"\n{'='*50}")
    print("恢复完成！" if not dry_run else "Dry run 完成，未写入任何数据。")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="恢复 OpenSearch 知识库到新环境")
    parser.add_argument("--dry-run", action="store_true", help="仅预览，不实际写入")
    parser.add_argument("--url", default="http://localhost:9200", help="OpenSearch 地址")
    args = parser.parse_args()
    restore(args.url, args.dry_run)
