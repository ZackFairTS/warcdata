# Athena Data Export

Budget analysis data for AWS Athena.

## Contents
- `data/` — 4 parquet files (budget_summary, budget_actuals, budget_plans, department_info)
- `setup_athena.sh` — One-shot init script: creates S3 bucket, uploads data, creates Glue DB/tables/views

## Usage
```bash
# Default: auto-detect region, auto-create bucket
bash setup_athena.sh

# Specify region and bucket
bash setup_athena.sh --region us-west-2 --bucket my-analytics-bucket
```

## Post-setup
Update `workspace-analyst/skills/athena-query/SKILL.md` with the new bucket name and region.
Update `budget-demo/scripts/athena_query.py` region if different from ap-northeast-1.
