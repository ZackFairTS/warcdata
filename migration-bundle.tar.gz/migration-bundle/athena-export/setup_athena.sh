#!/usr/bin/env bash
#
# setup_athena.sh — Initialize Athena database, tables, views, and upload data
#
# Usage:
#   bash setup_athena.sh [--region ap-northeast-1] [--bucket my-bucket-name]
#
# What it does:
#   1. Creates S3 bucket (if not provided, auto-generates: openclaw-analytics-<account_id>)
#   2. Uploads parquet data files to s3://<bucket>/budget-demo/
#   3. Creates Glue database: openclaw_analytics
#   4. Creates 4 external tables pointing to the S3 data
#   5. Creates 4 views for common analysis queries
#   6. Verifies with a test query
#

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
DATA_DIR="$SCRIPT_DIR/data"

# ── Parse args ──
REGION="${AWS_REGION:-ap-northeast-1}"
BUCKET=""

while [[ $# -gt 0 ]]; do
  case $1 in
    --region) REGION="$2"; shift 2 ;;
    --bucket) BUCKET="$2"; shift 2 ;;
    *) echo "Unknown arg: $1"; exit 1 ;;
  esac
done

# ── Get account ID ──
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
echo "📍 Account: $ACCOUNT_ID | Region: $REGION"

# ── Determine bucket ──
if [[ -z "$BUCKET" ]]; then
  # Look for existing openclaw-analytics bucket
  BUCKET=$(aws s3api list-buckets --query "Buckets[?starts_with(Name, 'openclaw-analytics-${ACCOUNT_ID}')].Name" \
    --output text 2>/dev/null | head -1)

  if [[ -z "$BUCKET" || "$BUCKET" == "None" ]]; then
    BUCKET="openclaw-analytics-${ACCOUNT_ID}"
    echo "🪣 Creating bucket: $BUCKET"
    if [[ "$REGION" == "us-east-1" ]]; then
      aws s3api create-bucket --bucket "$BUCKET" --region "$REGION"
    else
      aws s3api create-bucket --bucket "$BUCKET" --region "$REGION" \
        --create-bucket-configuration LocationConstraint="$REGION"
    fi
  fi
fi
echo "🪣 Using bucket: $BUCKET"

# ── Upload data files ──
echo "📤 Uploading parquet data files..."
for f in "$DATA_DIR"/*.parquet; do
  TABLE=$(basename "$f" .parquet)
  aws s3 cp "$f" "s3://$BUCKET/budget-demo/$TABLE/$TABLE.parquet" --region "$REGION" --quiet
  echo "  ✅ $TABLE"
done

# ── Athena output location ──
OUTPUT="s3://$BUCKET/athena-results/"

run_athena() {
  local sql="$1"
  local label="$2"
  local qid
  qid=$(aws athena start-query-execution \
    --query-string "$sql" \
    --query-execution-context Database=openclaw_analytics \
    --result-configuration OutputLocation="$OUTPUT" \
    --region "$REGION" --output text --query QueryExecutionId 2>/dev/null)

  # Wait for completion
  local state=""
  while true; do
    state=$(aws athena get-query-execution --query-execution-id "$qid" --region "$REGION" \
      --query 'QueryExecution.Status.State' --output text 2>/dev/null)
    [[ "$state" == "RUNNING" || "$state" == "QUEUED" ]] || break
    sleep 1
  done

  if [[ "$state" == "SUCCEEDED" ]]; then
    echo "  ✅ $label"
  else
    local reason
    reason=$(aws athena get-query-execution --query-execution-id "$qid" --region "$REGION" \
      --query 'QueryExecution.Status.StateChangeReason' --output text 2>/dev/null)
    echo "  ❌ $label ($state): $reason"
  fi
}

# ── Create database ──
echo ""
echo "📦 Creating database..."
run_athena "CREATE DATABASE IF NOT EXISTS openclaw_analytics" "openclaw_analytics database"

# ── Create tables ──
echo ""
echo "📋 Creating tables..."

run_athena "
CREATE EXTERNAL TABLE IF NOT EXISTS openclaw_analytics.budget_summary (
  quarter string,
  department string,
  department_en string,
  budget double,
  actual double,
  variance double,
  variance_rate double
)
STORED AS PARQUET
LOCATION 's3://$BUCKET/budget-demo/budget_summary/'
" "budget_summary"

run_athena "
CREATE EXTERNAL TABLE IF NOT EXISTS openclaw_analytics.budget_actuals (
  quarter string,
  department string,
  category string,
  month string,
  budget double,
  actual double,
  variance double
)
STORED AS PARQUET
LOCATION 's3://$BUCKET/budget-demo/budget_actuals/'
" "budget_actuals"

run_athena "
CREATE EXTERNAL TABLE IF NOT EXISTS openclaw_analytics.budget_plans (
  quarter string,
  department string,
  category string,
  month string,
  planned_budget double
)
STORED AS PARQUET
LOCATION 's3://$BUCKET/budget-demo/budget_plans/'
" "budget_plans"

run_athena "
CREATE EXTERNAL TABLE IF NOT EXISTS openclaw_analytics.department_info (
  department string,
  head string,
  title string,
  headcount int,
  key_projects string,
  key_expenses string,
  q3_budget bigint,
  q3_actual bigint,
  q3_variance bigint,
  q3_variance_rate double,
  main_reasons string
)
STORED AS PARQUET
LOCATION 's3://$BUCKET/budget-demo/department_info/'
" "department_info"

# ── Create views ──
echo ""
echo "📊 Creating views..."

run_athena "
CREATE OR REPLACE VIEW openclaw_analytics.v_budget_variance AS
SELECT
  quarter, department, category, month, budget, actual, variance,
  CASE WHEN budget > 0 THEN ROUND((variance / budget) * 100, 2) ELSE 0 END AS variance_pct
FROM openclaw_analytics.budget_actuals
" "v_budget_variance"

run_athena "
CREATE OR REPLACE VIEW openclaw_analytics.v_cost_breakdown AS
SELECT
  quarter, department, category,
  SUM(budget) AS total_budget,
  SUM(actual) AS total_actual,
  SUM(variance) AS total_variance
FROM openclaw_analytics.budget_actuals
GROUP BY quarter, department, category
" "v_cost_breakdown"

run_athena "
CREATE OR REPLACE VIEW openclaw_analytics.v_department_trend AS
SELECT
  quarter, department,
  SUM(budget) AS total_budget,
  SUM(actual) AS total_actual,
  SUM(variance) AS total_variance,
  CASE WHEN SUM(budget) > 0 THEN ROUND((SUM(variance) / SUM(budget)) * 100, 2) ELSE 0 END AS variance_rate
FROM openclaw_analytics.budget_actuals
GROUP BY quarter, department
" "v_department_trend"

run_athena "
CREATE OR REPLACE VIEW openclaw_analytics.v_overrun_alert AS
SELECT quarter, department, budget, actual, variance, variance_rate
FROM openclaw_analytics.budget_summary
WHERE variance_rate > 0.1
" "v_overrun_alert"

# ── Verify ──
echo ""
echo "🔍 Verifying with test query..."
run_athena "SELECT department, variance_rate FROM openclaw_analytics.budget_summary WHERE quarter = 'Q3' ORDER BY variance_rate DESC LIMIT 3" "Test query"

echo ""
echo "✅ Athena setup complete!"
echo "   Database: openclaw_analytics"
echo "   Bucket: $BUCKET"
echo "   Tables: budget_summary, budget_actuals, budget_plans, department_info"
echo "   Views: v_budget_variance, v_cost_breakdown, v_department_trend, v_overrun_alert"
echo ""
echo "📝 Update athena-query SKILL.md with:"
echo "   S3 Bucket: $BUCKET"
echo "   Output: s3://$BUCKET/athena-results/"
